package com.learnings.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.learnings.model.UserDetails;
import com.learnings.dao.SignUpLoginDao;

@Service("signUpLoginService")
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
public class SignUpLoginServiceImpl implements SignUpLoginService {
	
	@Autowired
	private SignUpLoginDao signUpLoginDao;
	
	@Override
	public List<UserDetails> listUsers(String emailId) {
		return signUpLoginDao.listUsers(emailId);
	}

	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public void addUser(UserDetails user) {
		signUpLoginDao.addUser(user);
		
	}

	@Override
	public UserDetails myProfile(Integer userId) {
		return signUpLoginDao.myProfile(userId);
	}

}
