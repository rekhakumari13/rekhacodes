package com.learnings.service;

import java.util.List;

import com.learnings.model.UserDetails;

public interface SignUpLoginService {

	public List<UserDetails> listUsers(String emailId);
	public void addUser(UserDetails user);
	public UserDetails myProfile(Integer userId);
}
