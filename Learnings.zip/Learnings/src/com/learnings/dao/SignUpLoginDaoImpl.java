package com.learnings.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.learnings.model.UserDetails;

@Repository("signUpLoginDao")
public class SignUpLoginDaoImpl implements SignUpLoginDao{
	
	@Autowired
	private SessionFactory sessionFactory;

	@SuppressWarnings("unchecked")
	public List<UserDetails> listUsers(String emailId) {
		String sql="from UserDetails where emailId='"+emailId+"'";
		return(List<UserDetails>) sessionFactory.getCurrentSession().createQuery(sql).list();
	}

	@Override
	public void addUser(UserDetails user) {
		String name=user.getFirstName();
		System.out.println(name);
		System.out.println("into putting");
		System.out.println(user);
		sessionFactory.getCurrentSession().saveOrUpdate(user);
		System.out.println("out putting");
		System.out.println("out putting");
		
	}
	@Override
	public UserDetails myProfile(Integer userId) {
		System.out.println(userId);
		return(UserDetails) sessionFactory.getCurrentSession().get(UserDetails.class, userId);
	}

}
