package com.learnings.dao;

import java.util.List;

import com.learnings.model.UserDetails;

public interface SignUpLoginDao {

	public List<UserDetails> listUsers(String emailId);
	public void addUser(UserDetails user);
	public UserDetails myProfile(Integer userId);
}