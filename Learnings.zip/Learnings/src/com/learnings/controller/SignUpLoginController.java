package com.learnings.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.learnings.model.UserDetails;
import com.learnings.service.SignUpLoginService;

@Controller
public class SignUpLoginController {
	
	@Autowired
	private SignUpLoginService signUpLoginService;
	@RequestMapping("/signUpLogin")
	public ModelAndView SignUpLogin(@ModelAttribute UserDetails user) {
		return new ModelAndView("signUpLogin");
	}

	@RequestMapping("/registerUser")
	public ModelAndView registerUser(@ModelAttribute UserDetails user) {
		String emailId = user.getEmailId();
		String view;
		String message = "";
		List<UserDetails> users = signUpLoginService.listUsers(emailId);
		if (users.isEmpty()) {
			signUpLoginService.addUser(user);
			message = "sign here";
			view = "signUpLogin";
		} else {
			System.out
			.println("emailId already exist,signup with a new emailId");
			message = "emailId already exist,signup with a new emailId";
			view = "signUpLogin";
		}
		return new ModelAndView(view, "message", message);
	}

	@RequestMapping("/login")
	public ModelAndView login(@ModelAttribute UserDetails user,
			HttpSession session) {
		String emailId = user.getEmailId();
		String password = user.getPassword();
		String view = null;
		String message = "";
		List<UserDetails> loginValidate = signUpLoginService.listUsers(emailId);
		if (loginValidate.size() > 0) {
			for (UserDetails userDetails : loginValidate) {
				if (password.equals(userDetails.getPassword())) {
					session.setAttribute("firstName",userDetails.getFirstName());
					session.setAttribute("emailId", userDetails.getEmailId());
					session.setAttribute("userId", userDetails.getUserId());
					message = "u r valid user";
					System.out.println("u r valid user");
					view = "home";
				} else {
					message = "invalid credential";
					System.out.println("invalid credential");
					view = "signUp1";
				}
			}
		} else {
			message = "emailid not found,go to signup page";
			view = "signUpLogin";
		}
		return new ModelAndView(view, "message", message);				
	}

	@RequestMapping("/logout")  
	public ModelAndView logOut(HttpSession session) {
		String message = "";
		session.removeAttribute("userId");
		message="loggedoout successfully";
		return new ModelAndView("signUpLogin","message",message);  
	}

	@Scope("session")
	@RequestMapping("/myProfile")
	public ModelAndView myProfile(@ModelAttribute UserDetails user,HttpSession session) {
		Integer userId=(Integer) session.getAttribute("userId");
		UserDetails myProfile=signUpLoginService.myProfile(userId);
		return new ModelAndView("myProfile", "myProfile",myProfile);
	}

	@Scope("session")
	@RequestMapping("/editProfile")
	public ModelAndView editProfile(@ModelAttribute UserDetails user,HttpSession session) {
		Integer userId=(Integer) session.getAttribute("userId");
		UserDetails editProfile=signUpLoginService.myProfile(userId);
		return new ModelAndView("editProfile", "editProfile",editProfile);	
	}

	@Scope("session")
	@RequestMapping("/saveEditedProfile")
	public String saveEditedProfile(@ModelAttribute UserDetails user,HttpSession session) {
		Integer userId=(Integer) session.getAttribute("userId");
		user.setUserId(userId);
		signUpLoginService.addUser(user);
		return "redirect:/myProfile.html";
	}
}
