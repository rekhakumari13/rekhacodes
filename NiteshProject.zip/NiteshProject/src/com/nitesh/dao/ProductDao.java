package com.nitesh.dao;

import java.util.List;

import com.nitesh.model.UserModel;

public interface ProductDao {
	public void addUser(UserModel model);
	public List<UserModel> getUserDetails(String emailId);

}
