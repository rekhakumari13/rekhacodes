package com.nitesh.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.nitesh.model.UserModel;

@Repository("productdao")
public class ProductDaoImpl implements ProductDao{
	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public void addUser(UserModel model) {
		sessionFactory.getCurrentSession().saveOrUpdate(model);
		
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<UserModel> getUserDetails(String emailId) {
		String sql="into UserModel where emailId='"+emailId+"'";
		return (List<UserModel>) sessionFactory.getCurrentSession().createQuery(sql);
	}

}
