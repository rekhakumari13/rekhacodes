package com.nitesh.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.annotation.Propagation;

import com.nitesh.dao.ProductDao;
import com.nitesh.model.UserModel;
@Service("productService")
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
public class ProductServiceImpl implements ProductService {

	@Autowired
	private ProductDao productDao;

	

	@Override
	public List<UserModel> getUserDetails(String emailId) {
		return productDao.getUserDetails(emailId);
	}



	@Override
	public void addUser(UserModel model) {
		productDao.addUser(model);
		
	}
	
	
}
