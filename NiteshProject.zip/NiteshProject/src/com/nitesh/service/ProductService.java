package com.nitesh.service;

import java.util.List;

import com.nitesh.model.UserModel;

public interface ProductService {
	public void addUser(UserModel model);
	public List<UserModel> getUserDetails(String emailId);

}
