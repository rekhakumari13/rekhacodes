package com.nitesh.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.nitesh.model.UserModel;
import com.nitesh.service.ProductService;

@Controller
public class ProductController {
	@Autowired
	private ProductService productService;
	
	
	@RequestMapping("/signUpLogin")
	public ModelAndView SignUpLogin(@ModelAttribute UserModel model) {
		String message="";
		String view=null;
		String emailId=model.getEmailId();
		List<UserModel> listUser=productService.getUserDetails(emailId);
		if(listUser.isEmpty()){
			productService.addUser(model);
			message="welcome to home page";
			view="home";
			
		}
		else{
			message="your data is already with us go to login page...or signup with a new emailid";
			view="index";
			
		}
		return new ModelAndView(view,"message",message);
	}

}
