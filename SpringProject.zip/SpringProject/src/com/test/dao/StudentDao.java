package com.test.dao;

import java.util.List;

import com.test.model.Student;
import com.test.model.Team;

public interface StudentDao {

	public List<Student> listUsers(String emailId);
	public void addUser(Student student);
	public Student myProfile(Integer userId);
	public List<Student> listTotalUsers(Integer userId);
	public void deleteUser(Integer id);
	public void updateNewPassword(String newPassword, Integer userId);
	public List<Team> teamList();
	public void saveEditedProfile(Student student);
}
