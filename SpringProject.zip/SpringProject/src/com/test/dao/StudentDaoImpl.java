package com.test.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.test.model.Student;
import com.test.model.Team;

@Repository("studentDao")
public class StudentDaoImpl implements StudentDao {

	@Autowired
	private SessionFactory sessionFactory;

	@SuppressWarnings("unchecked")
	@Override
	public List<Student> listUsers(String emailId) {
		String sql="from Student where emailId='"+emailId+"'";
		return(List<Student>) sessionFactory.getCurrentSession().createQuery(sql).list();
	}

	@Override
	public void addUser(Student student) {
		System.out.println("into save");
		sessionFactory.getCurrentSession().saveOrUpdate(student);
		System.out.println("out save");
	}

	@Override
	public Student myProfile(Integer userId) {
		return(Student) sessionFactory.getCurrentSession().get(Student.class, userId);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Student> listTotalUsers(Integer userId) {
		String sql="from Student where id!='"+userId+"'";
		return(List<Student>) sessionFactory.getCurrentSession().createQuery(sql).list();
	}

	@Override
	public void deleteUser(Integer id) {
		sessionFactory.getCurrentSession().createQuery("DELETE FROM Student WHERE id = "+id).executeUpdate();
	}

	@Override
	public void updateNewPassword(String newPassword, Integer userId) {
		System.out.println("into change password");
		String sql="UPDATE Student SET password ='"+newPassword+"' where id='"+userId+"'";
		sessionFactory.getCurrentSession().createQuery(sql).executeUpdate();
		System.out.println("out of change password");
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Team> teamList() {
		String sql="from Team";
		System.out.println("hello");
		return(List<Team>) sessionFactory.getCurrentSession().createQuery(sql).list();
	}

	@Override
	public void saveEditedProfile(Student student) {
		String sql="UPDATE Student SET firstName ='"+student.getFirstName()+"',lastName ='"+student.getLastName()+"',phoneNo ='"+student.getPhoneNo()+"' where emailId='"+student.getEmailId()+"'";
		sessionFactory.getCurrentSession().createQuery(sql).executeUpdate();
		
	}
}
