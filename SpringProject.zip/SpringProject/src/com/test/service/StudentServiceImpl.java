package com.test.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.annotation.Propagation;

import com.test.dao.StudentDao;
import com.test.model.Student;
import com.test.model.Team;

@Service("studentService")
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
public class StudentServiceImpl implements StudentService  {

	@Autowired
	private StudentDao studentDao;

	@Override
	public List<Student> listUsers(String emailId) {

		return studentDao.listUsers(emailId);
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public void addUser(Student student) {
		studentDao.addUser(student);
	}

	@Override
	public Student myProfile(Integer userId) {
		return studentDao.myProfile(userId);
	}

	@Override
	public List<Student> listTotalUsers(Integer userId) {
		return studentDao.listTotalUsers(userId);
	}

	@Override
	public void deleteUser(Integer id) {
		studentDao.deleteUser(id);
	}

	@Override
	public void updateNewPassword(String newPassword, Integer userId) {
		studentDao.updateNewPassword(newPassword, userId);

	}

	@Override
	public List<Team> teamList() {
		return studentDao.teamList();
	}

	@Override
	public void saveEditedProfile(Student student) {
		studentDao.saveEditedProfile(student);
		
	}
}
