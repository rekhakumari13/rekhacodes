package com.test.model;


import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.sun.istack.NotNull;

@Entity
@Table(name="Answer")
public class Answer implements Serializable  {
	
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue
	@Column(name = "answerId")
	private int answerId;
	
	@Column(name = "answerName")
	private String answerName;
	
	@ManyToOne()
	@JoinColumn(name="questionId",referencedColumnName="questionId")
	private Question question;
	
	@OneToOne(targetEntity=Student.class,cascade=CascadeType.ALL)
	@JoinColumn(name="userId",referencedColumnName="id")
	private Student student;

}
