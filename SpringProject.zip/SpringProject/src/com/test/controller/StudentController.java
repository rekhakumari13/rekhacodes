package com.test.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.test.model.Student;
import com.test.model.Team;
import com.test.service.StudentService;


@Controller
public class StudentController {

	@Autowired
	private StudentService studentService;

	@RequestMapping("/signUpLogin")
	public ModelAndView signUpLogin(@ModelAttribute Student student) {
		List<Team> teamList = studentService.teamList();
		return new ModelAndView("index","teamList",teamList);
	}

	@RequestMapping("/registerUser")
	public ModelAndView registerUser(@ModelAttribute Student student,Boolean admin) {
		if(admin == null){
		student.setAdmin(false);
		}
		System.out.println(student);
		String emailId = student.getEmailId();
		String message = "";
		String view = "";
		List<Student> list = studentService.listUsers(emailId);
		if (list.isEmpty()) {
			studentService.addUser(student);
			view = "index";
		} else {
			System.out.println("emailId already exist,signup with a new emailId");
			message = "emailId already exist,signup with a new emailId";
			view = "index";
		}
		return new ModelAndView(view, "message", message);
	}

	@RequestMapping("/loginUser")
	public ModelAndView loginUser(String emailId, String password,HttpSession session) {
		String view = null;
		String message = "";
		List<Student> list = studentService.listUsers(emailId);
		if (list.size() > 0) {
			for (Student studentDetails : list) {
				if (password.equals(studentDetails.getPassword())) {
					if(studentDetails.getAdmin()){
						session.setAttribute("isAdmin", true);
					}else{
						session.setAttribute("isAdmin", false);
					}
					session.setAttribute("id", studentDetails.getId());
					session.setAttribute("name", studentDetails.getFirstName());
					session.setAttribute("password", studentDetails.getPassword());
					session.setAttribute("emailId", studentDetails.getEmailId());
					message = "Welcome : "+studentDetails.getFirstName();
					System.out.println("u r valid user");
					view = "home";
				} else {
					message = "invalid credential";
					System.out.println("invalid credential");
					view = "index";
				}
			}
		} else {
			message = "emailid not found,go to signup page";
			view = "index";
		}
		return new ModelAndView(view, "message", message);				
	}

	@Scope("session")
	@RequestMapping("/logout")  
	public String logOut(HttpSession session) {
		session.removeAttribute("id");
		session.invalidate();
		return "redirect:/signUpLogin.html"; 
	}

	@Scope("session")
	@RequestMapping("/myProfile")
	public ModelAndView myProfile(@ModelAttribute Student user,HttpSession session) {
		Integer userId=(Integer) session.getAttribute("id");
		Student myProfile=studentService.myProfile(userId);
		return new ModelAndView("myProfile", "myProfile",myProfile);
	}

	@Scope("session")
	@RequestMapping("/editProfile")
	public ModelAndView editProfile(@ModelAttribute Student user,HttpSession session) {
		Integer userId=(Integer) session.getAttribute("id");
		Student editProfile=studentService.myProfile(userId);
		return new ModelAndView("editProfile", "editProfile",editProfile);	
	}

	@RequestMapping("/saveEditedProfile")
	public String saveEditedProfile(@ModelAttribute Student student,HttpSession session) {
		studentService.saveEditedProfile(student);
		return "redirect:/myProfile.html";
	}

	@Scope("session")
	@RequestMapping("/listTotalUsers")
	public ModelAndView listTotalUsers(HttpSession session) {
		Integer userId=(Integer) session.getAttribute("id");
		List<Student> listTotalUsers = studentService.listTotalUsers(userId);
		System.out.println(listTotalUsers);
		return new ModelAndView("listTotalUsers", "listTotalUsers",listTotalUsers);	
	}

	@Scope("session")
	@RequestMapping("/getUsersForEdit")
	public ModelAndView getUsersForEdit(HttpSession session) {
		Integer userId=(Integer) session.getAttribute("id");
		List<Student> getUsersForEdit = studentService.listTotalUsers(userId);
		System.out.println(getUsersForEdit);
		return new ModelAndView("getUsersForEdit", "getUsersForEdit",getUsersForEdit);	
	}


	@SuppressWarnings("rawtypes")
	@RequestMapping("/editUser")
	public ModelAndView editUser(@ModelAttribute Student student,String emailId) {
		List<Team> teamList = studentService.teamList();
		List<Student> editUser = studentService.listUsers(emailId);
		Map<String, List> map = new HashMap<String, List>();
		map.put("teamList", teamList);
		map.put("editUser", editUser);
		
		return new ModelAndView("editUser", "map",map);	
	}

	@RequestMapping("/saveEditedUser")
	public String saveEditedUser(@ModelAttribute Student student,Boolean admin) {
		if(admin == null){
			student.setAdmin(false);
			}
		studentService.addUser(student);
		return "redirect:/getUsersForEdit.html";
	}

	@RequestMapping("/deleteUser")
	public String deleteUser(Integer id) {
		studentService.deleteUser(id);
		return "redirect:/getUsersForEdit.html";	
	}

	@RequestMapping("/changePassword")
	public ModelAndView changePassword() {
		return new ModelAndView("changePassword");
	}

	@Scope("session")
	@RequestMapping("/updateNewPassword")
	public ModelAndView updateNewPassword(String oldPassword, String newPassword,HttpSession session) {
		String view="";
		String message="";
		Integer userId=(Integer) session.getAttribute("id");
		Student myProfile=studentService.myProfile(userId);
		String password = myProfile.getPassword();
		if(password.equals(oldPassword)){
			studentService.updateNewPassword(newPassword,userId);
			message="Password changed successfully";
			view="home";
		}
		else{
			message="Please enter Correct Old Password";
			view="changePassword";
		}
		return new ModelAndView(view,"message",message);
	}

	@RequestMapping("/addUserPage")
	public ModelAndView addUserPage(@ModelAttribute Student student) {
		List<Team> teamList = studentService.teamList();
		return new ModelAndView("addUser","teamList",teamList);
	}
	
	@RequestMapping("/addUser")
	public ModelAndView addUser(@ModelAttribute Student student,Boolean admin) {
		if(admin == null){
			student.setAdmin(false);
			}
		String emailId = student.getEmailId();
		String message = "";
		String view = "";
		List<Student> list = studentService.listUsers(emailId);
		if (list.isEmpty()) {
			student.setPassword("test123");
			studentService.addUser(student);
			message="User added Successfully";
			view = "home";
		} else {
			System.out.println("emailId already exist,signup with a new emailId");
			message = "EmailId already exist,add with a new emailId";
			view = "addUser";
		}
		return new ModelAndView(view, "message", message);
	}
}
