/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cg.discover.ets.excelcreater;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRichTextString;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import com.cg.discover.ets.entity.TaskTime;
import com.cg.discover.ets.vo.UsersReport;

/**
 *
 * @author nranjan
 */
public class ExcelCreator {

    public HSSFWorkbook createWorkbook(List<UsersReport> usersReport) throws Exception {

        HSSFWorkbook wb = new HSSFWorkbook();
        HSSFSheet sheet = wb.createSheet("User Data");

        /**
         * Setting the width of the first three columns.
         */
        sheet.setColumnWidth(0, 3500);
        sheet.setColumnWidth(1, 7500);
        sheet.setColumnWidth(2, 5000);

        /**
         * Style for the header cells.
         */
        HSSFCellStyle headerCellStyle = wb.createCellStyle();
        HSSFFont boldFont = wb.createFont();
        boldFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
        headerCellStyle.setFont(boldFont);

        HSSFRow row = sheet.createRow(0);
        HSSFCell cell = row.createCell(0);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("BU"));
        cell = row.createCell(1);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("Team Name"));
        cell = row.createCell(2);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("Employee Name"));
        cell = row.createCell(3);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("Date"));
        
        Set<TaskTime> taskTimeList = usersReport.get(0).getTaskTimeSet();
        int count = 4;
        for (TaskTime taskTime : taskTimeList) {
        	cell = row.createCell(count);
            cell.setCellStyle(headerCellStyle);
            cell.setCellValue(new HSSFRichTextString(taskTime.getTask().getTaskName()));
            count++;
		}
        
        cell = row.createCell(count);
        cell.setCellStyle(headerCellStyle);
        cell.setCellValue(new HSSFRichTextString("Total"));

        for (int index = 1; index < usersReport.size()+1; index++) {
            row = sheet.createRow(index);
            cell = row.createCell(0);
            UsersReport userReport = usersReport.get(index-1);
            HSSFRichTextString bu = new HSSFRichTextString(userReport.getBuName());
            cell.setCellValue(bu);
            cell = row.createCell(1);
            HSSFRichTextString teamName = new HSSFRichTextString(userReport.getTeamName());
            cell.setCellValue(teamName);
            cell = row.createCell(2);
            HSSFRichTextString employeeName = new HSSFRichTextString(userReport.getEmployeeName());
            cell.setCellValue(employeeName);
            cell = row.createCell(3);
            HSSFRichTextString date = new HSSFRichTextString(userReport.getTaskDate());
            cell.setCellValue(date);
            
            int i = 4;
            Set<TaskTime> taskTimes = userReport.getTaskTimeSet();
            for (TaskTime taskTime : taskTimes) {
            	cell = row.createCell(i);
            	String tt = ""; 
            	if(taskTime.getTaskTimeHour() != null){
            		tt = ""+taskTime.getTaskTimeHour();
            	}else{
            		tt = "0";
            	}
            	
                HSSFRichTextString task = new HSSFRichTextString(tt);
                cell.setCellValue(task);
                i++;
			}

            
            String totalStr = userReport.getTotal();
            if(totalStr == "" || totalStr == null){
            	totalStr = "0";
            }
            cell = row.createCell(i);
            HSSFRichTextString total = new HSSFRichTextString(totalStr);
            cell.setCellValue(total);
        }
        System.out.println(wb);
        return wb;
    }
}
