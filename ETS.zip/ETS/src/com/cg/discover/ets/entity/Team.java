/**
 * 
 */
package com.cg.discover.ets.entity;

import java.io.Serializable;
public class Team implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;


	private Integer teamNameId;
	private String teamName;
	private Integer BUId;
	//private BU BU;
	public Integer getTeamNameId() {
		return teamNameId;
	}
	public void setTeamNameId(Integer teamNameId) {
		this.teamNameId = teamNameId;
	}
	public String getTeamName() {
		return teamName;
	}
	public void setTeamName(String teamName) {
		this.teamName = teamName;
	}
	public Integer getBUId() {
		return BUId;
	}
	public void setBUId(Integer bUId) {
		BUId = bUId;
	}
	@Override
	public String toString() {
		return "Team [teamNameId=" + teamNameId + ", teamName=" + teamName
				+ ", BUId=" + BUId + "]";
	}
	
	

}
