/**
 * 
 */
package com.cg.discover.ets.entity;


/**
 * @author nranjan
 *
 */
public class TaskTime{
	private Integer taskTimeId;
	private Float taskTimeHour;
	private Task task;
	/**
	 * @return the taskTimeId
	 */
	public Integer getTaskTimeId() {
		return taskTimeId;
	}
	/**
	 * @param taskTimeId the taskTimeId to set
	 */
	public void setTaskTimeId(Integer taskTimeId) {
		this.taskTimeId = taskTimeId;
	}
	/**
	 * @return the taskTimeHour
	 */
	public Float getTaskTimeHour() {
		return taskTimeHour;
	}
	/**
	 * @param taskTimeHour the taskTimeHour to set
	 */
	public void setTaskTimeHour(Float taskTimeHour) {
		this.taskTimeHour = taskTimeHour;
	}
	/**
	 * @return the task
	 */
	public Task getTask() {
		return task;
	}
	/**
	 * @param task the task to set
	 */
	public void setTask(Task task) {
		this.task = task;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "TaskTime [taskTimeId=" + taskTimeId + ", taskTimeHour="
				+ taskTimeHour + ", task=" + task + "]";
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((task == null) ? 0 : task.hashCode());
		result = prime * result
				+ ((taskTimeHour == null) ? 0 : taskTimeHour.hashCode());
		result = prime * result
				+ ((taskTimeId == null) ? 0 : taskTimeId.hashCode());
		return result;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TaskTime other = (TaskTime) obj;
		if (task == null) {
			if (other.task != null)
				return false;
		} else if (!task.equals(other.task))
			return false;
		if (taskTimeHour == null) {
			if (other.taskTimeHour != null)
				return false;
		} else if (!taskTimeHour.equals(other.taskTimeHour))
			return false;
		if (taskTimeId == null) {
			if (other.taskTimeId != null)
				return false;
		} else if (!taskTimeId.equals(other.taskTimeId))
			return false;
		return true;
	}
	
}
