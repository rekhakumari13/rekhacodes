/**
 * 
 */
package com.cg.discover.ets.entity;

import java.util.Date;
import java.util.Set;

/**
 * @author nranjan
 *
 */
public class Track {
	private Integer trackId;
	private String trackDate;
	private BU BU;
	private Date taskDate;
	private String taskDateStr;
	private String userName;
	private Set<TaskTime> taskTimeSet;
	private Float total;
	
	/**
	 * @return the trackId
	 */
	public Integer getTrackId() {
		return trackId;
	}
	/**
	 * @param trackId the trackId to set
	 */
	public void setTrackId(Integer trackId) {
		this.trackId = trackId;
	}
	/**
	 * @return the bU
	 */
	public BU getBU() {
		return BU;
	}
	/**
	 * @param bU the bU to set
	 */
	public void setBU(BU bU) {
		BU = bU;
	}
	/**
	 * @return the taskDate
	 */
	public Date getTaskDate() {
		return taskDate;
	}
	/**
	 * @param taskDate the taskDate to set
	 */
	public void setTaskDate(Date taskDate) {
		this.taskDate = taskDate;
	}
	/**
	 * @return the taskTimeSet
	 */
	public Set<TaskTime> getTaskTimeSet() {
		return taskTimeSet;
	}
	/**
	 * @param taskTimeSet the taskTimeSet to set
	 */
	public void setTaskTimeSet(Set<TaskTime> taskTimeSet) {
		this.taskTimeSet = taskTimeSet;
	}
	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}
	/**
	 * @param userName the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}
	/**
	 * @return the trackDate
	 */
	public String getTrackDate() {
		return trackDate;
	}
	/**
	 * @param trackDate the trackDate to set
	 */
	public void setTrackDate(String trackDate) {
		this.trackDate = trackDate;
	}
	
	/**
	 * @return the taskDateStr
	 */
	public String getTaskDateStr() {
		return taskDateStr;
	}
	/**
	 * @param taskDateStr the taskDateStr to set
	 */
	public void setTaskDateStr(String taskDateStr) {
		this.taskDateStr = taskDateStr;
	}
	
	/**
	 * @return the total
	 */
	public Float getTotal() {
		return total;
	}
	/**
	 * @param total the total to set
	 */
	public void setTotal(Float total) {
		this.total = total;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Track [trackId=" + trackId + ", trackDate=" + trackDate
				+ ", BU=" + BU + ", taskDate=" + taskDate + ", taskDateStr="
				+ taskDateStr + ", userName=" + userName + ", taskTimeSet="
				+ taskTimeSet + ", total=" + total + "]";
	}
	
}
