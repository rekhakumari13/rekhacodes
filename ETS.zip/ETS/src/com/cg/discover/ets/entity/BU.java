/**
 * 
 */
package com.cg.discover.ets.entity;

/**
 * @author nranjan
 *
 */
public class BU {
	
	private Integer BUId;
	private String BU;
	public Integer getBUId() {
		return BUId;
	}
	public void setBUId(Integer bUId) {
		BUId = bUId;
	}
	public String getBU() {
		return BU;
	}
	public void setBU(String bU) {
		BU = bU;
	}
	@Override
	public String toString() {
		return "BU [BUId=" + BUId + ", BU=" + BU + "]";
	}
	
}
