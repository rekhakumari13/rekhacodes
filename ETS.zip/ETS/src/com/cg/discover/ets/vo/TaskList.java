package com.cg.discover.ets.vo;




public class TaskList {

	private Integer taskId;
	private Integer BUId;
	private String taskName;
	private String taskDescription;
	private String BU;
	
	public Integer getTaskId() {
		return taskId;
	}
	public void setTaskId(Integer taskId) {
		this.taskId = taskId;
	}
	public Integer getBUId() {
		return BUId;
	}
	public void setBUId(Integer bUId) {
		BUId = bUId;
	}
	public String getTaskName() {
		return taskName;
	}
	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}
	public String getTaskDescription() {
		return taskDescription;
	}
	public void setTaskDescription(String taskDescription) {
		this.taskDescription = taskDescription;
	}
	public String getBU() {
		return BU;
	}
	public void setBU(String bU) {
		BU = bU;
	}
	@Override
	public String toString() {
		return "TaskList [taskId=" + taskId + ", BUId=" + BUId + ", taskName="
				+ taskName + ", taskDescription=" + taskDescription + ", BU="
				+ BU + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((BU == null) ? 0 : BU.hashCode());
		result = prime * result + ((BUId == null) ? 0 : BUId.hashCode());
		result = prime * result
				+ ((taskDescription == null) ? 0 : taskDescription.hashCode());
		result = prime * result + ((taskId == null) ? 0 : taskId.hashCode());
		result = prime * result
				+ ((taskName == null) ? 0 : taskName.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TaskList other = (TaskList) obj;
		if (BU == null) {
			if (other.BU != null)
				return false;
		} else if (!BU.equals(other.BU))
			return false;
		if (BUId == null) {
			if (other.BUId != null)
				return false;
		} else if (!BUId.equals(other.BUId))
			return false;
		if (taskDescription == null) {
			if (other.taskDescription != null)
				return false;
		} else if (!taskDescription.equals(other.taskDescription))
			return false;
		if (taskId == null) {
			if (other.taskId != null)
				return false;
		} else if (!taskId.equals(other.taskId))
			return false;
		if (taskName == null) {
			if (other.taskName != null)
				return false;
		} else if (!taskName.equals(other.taskName))
			return false;
		return true;
	}
	
	

	
}
