package com.cg.discover.ets.vo;

import java.util.Set;

import com.cg.discover.ets.entity.TaskTime;

public class UsersReport {

	private String buName;
	private String teamName;
	private String employeeName;
	private String taskDate;
	private Set<TaskTime> taskTimeSet;
	private String total;
	
	
	public String getBuName() {
		return buName;
	}
	public void setBuName(String buName) {
		this.buName = buName;
	}
	public String getTeamName() {
		return teamName;
	}
	public void setTeamName(String teamName) {
		this.teamName = teamName;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public String getTaskDate() {
		return taskDate;
	}
	public void setTaskDate(String taskDate) {
		this.taskDate = taskDate;
	}
	public Set<TaskTime> getTaskTimeSet() {
		return taskTimeSet;
	}
	public void setTaskTimeSet(Set<TaskTime> taskTimeSet) {
		this.taskTimeSet = taskTimeSet;
	}
	public String getTotal() {
		return total;
	}
	public void setTotal(String total) {
		this.total = total;
	}
	
}
