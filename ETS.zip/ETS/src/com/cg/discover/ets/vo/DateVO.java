/**
 * 
 */
package com.cg.discover.ets.vo;

/**
 * @author nranjan
 *
 */
public class DateVO {
	private String dateStr;
	private String fullDate;
	
	
	/**
	 * @param dateStr
	 * @param fullDate
	 */
	public DateVO(String dateStr, String fullDate) {
		super();
		this.dateStr = dateStr;
		this.fullDate = fullDate;
	}
	/**
	 * @return the dateStr
	 */
	public String getDateStr() {
		return dateStr;
	}
	/**
	 * @param dateStr the dateStr to set
	 */
	public void setDateStr(String dateStr) {
		this.dateStr = dateStr;
	}
	/**
	 * @return the fullDate
	 */
	public String getFullDate() {
		return fullDate;
	}
	/**
	 * @param fullDate the fullDate to set
	 */
	public void setFullDate(String fullDate) {
		this.fullDate = fullDate;
	}
	
	
}
