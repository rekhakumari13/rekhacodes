package com.cg.discover.ets.action;

import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.struts2.ServletActionContext;

import com.cg.discover.ets.entity.BU;
import com.cg.discover.ets.entity.Team;
import com.cg.discover.ets.entity.UserLogin;
import com.cg.discover.ets.excelcreater.ExcelCreator;
import com.cg.discover.ets.exception.ETSException;
import com.cg.discover.ets.service.BuServiceImpl;
import com.cg.discover.ets.service.TeamNameServiceImpl;
import com.cg.discover.ets.service.UsersReportService;
import com.cg.discover.ets.service.UsersReportServiceImpl;
import com.cg.discover.ets.service.UsersServiceImpl;
import com.cg.discover.ets.vo.UserSearch;
import com.cg.discover.ets.vo.UsersReport;
import com.opensymphony.xwork2.ActionSupport;

public class UsersReportAction extends ActionSupport  {

	
	private String fromDate;
	private String toDate;
	private Integer BUId;
	private String buName;
	private String teamId;
	private String teamName;
	private String associateName;
	String errorMessage = null;
		
	UsersServiceImpl userServiceImpl = new UsersServiceImpl();
	List<UserLogin> userList = new ArrayList<UserLogin>();
	UsersReportService service = new UsersReportServiceImpl();
	BuServiceImpl buServiceImpl = new BuServiceImpl();
	TeamNameServiceImpl teamNameServiceImpl = new TeamNameServiceImpl();
	List<BU> buList = new ArrayList<BU>();
	Set<Team> teamNameList = new HashSet<Team>();
	
	 public String exportUsersReport(){
		 try{
		 	HttpServletResponse response = ServletActionContext.getResponse();
		 	
		 	UserSearch userSearch = new UserSearch();
		 	userSearch.setAssociateName(associateName);
		 	userSearch.setBuName(buName);
		 	userSearch.setFromDate(fromDate);
		 	userSearch.setTeamName(teamName);
		 	userSearch.setToDate(toDate);
		 	
	        List<UsersReport> usersReport = service.gerUsersReport(userSearch);
	        
	        ExcelCreator excelCreator = new ExcelCreator();
	        HSSFWorkbook workbook = excelCreator.createWorkbook(usersReport);
	        response.setHeader("Content-Disposition", "attachment; filename=UserDetails.xls");
	        ServletOutputStream out = response.getOutputStream();
	        workbook.write(out);
	        out.flush();
	        out.close();
	        
		 }
		 catch(Exception e)
		 {
			 System.out.println(e.getMessage());
			 return "failure";
		 }
		 return "success";
	    }
	 public String getList() {
			
			try {
				buList = buServiceImpl.getBUList();
				teamNameList = teamNameServiceImpl.getTeamNameList();
				userList = teamNameServiceImpl.getEmployeesName(teamId,BUId);
				//Collections.sort(userList);
			} catch (ETSException e) {
				errorMessage = e.getMessage();
				return "failure";
			}
			return "success";
		}
		
		 public String getEmployeesName() {
			 buList = null;
			 teamNameList = null;
			 userList = null;
			try {
				
				buList = buServiceImpl.getBUList();
				teamNameList = teamNameServiceImpl.getTeamNamesById(BUId);
				userList = teamNameServiceImpl.getEmployeesName(teamId,BUId);
				//Collections.sort(userList);
			} catch (ETSException e) {
				errorMessage = e.getMessage();
				return "failure";
			}
			return "success";
		}
		 
		 public String getEmployeesNameForTeam() {
			 buList = null;
			 teamNameList = null;
			 userList = null;
				try {
					
					buList = buServiceImpl.getBUList();
					teamNameList = teamNameServiceImpl.getTeamNamesById(BUId);
					userList = teamNameServiceImpl.getEmployeesName(teamId,BUId);
				} catch (ETSException e) {
					errorMessage = e.getMessage();
					return "failure";
				}
				return "success";
			}
			public String getFromDate() {
				return fromDate;
			}

			public void setFromDate(String fromDate) {
				this.fromDate = fromDate;
			}

			public String getToDate() {
				return toDate;
			}

			public void setToDate(String toDate) {
				this.toDate = toDate;
			}

			public String getBuName() {
				return buName;
			}

			public void setBuName(String buName) {
				this.buName = buName;
			}

			public String getTeamName() {
				return teamName;
			}

			public void setTeamName(String teamName) {
				this.teamName = teamName;
			}

			public String getAssociateName() {
				return associateName;
			}

			public void setAssociateName(String associateName) {
				this.associateName = associateName;
			}

			
			public String getErrorMessage() {
				return errorMessage;
			}

			public void setErrorMessage(String errorMessage) {
				this.errorMessage = errorMessage;
			}

			public List<UserLogin> getUserList() {
				return userList;
			}

			public void setUserList(List<UserLogin> userList) {
				this.userList = userList;
			}

			public Integer getBUId() {
				return BUId;
			}

			public void setBUId(Integer bUId) {
				BUId = bUId;
			}

			public List<BU> getBuList() {
				return buList;
			}

			public void setBuList(List<BU> buList) {
				this.buList = buList;
			}

			public Set<Team> getTeamNameList() {
				return teamNameList;
			}

			public void setTeamNameList(Set<Team> teamNameList) {
				this.teamNameList = teamNameList;
			}

			public String getTeamId() {
				return teamId;
			}

			public void setTeamId(String teamId) {
				this.teamId = teamId;
			}
			
	 
	 
}
