package com.cg.discover.ets.action;

import java.util.Map;
import com.cg.discover.ets.exception.ETSException;
import com.cg.discover.ets.service.LoginService;
import com.cg.discover.ets.service.LoginServiceImpl;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ActionContext;

@SuppressWarnings("serial")
public class LoginAction extends ActionSupport {
	private String username;
	private String password;
	private String oldPassword;
	private String newPassword;
	
	String errorMessage = null;
	LoginService loginServiceImpl = new LoginServiceImpl();

	public String execute() {

		Boolean isValid = null;
		System.out.println("userLogin Name =" + username);
		try {
			isValid = loginServiceImpl.login(username, password);
			if(isValid){
				return "success";
			}else{
				errorMessage = "Invalid Username or Password";
				return "failure";
			}
		} catch (ETSException e) {
			errorMessage = e.getMessage();
			return "failure";
		}
		
		
	}
	@SuppressWarnings("rawtypes")
	public String logout() throws Exception {
		Map session = ActionContext.getContext().getSession();
		session.remove("userName");
		return "success";
	}
	
	public String changePassword() throws Exception {
		try {
			System.out.println(oldPassword);
			System.out.println(newPassword);
			return loginServiceImpl.changePassword(oldPassword, newPassword);
		} catch (ETSException e) {
			errorMessage = e.getMessage();
			return "failure";
		}
		
	}
	
	/**
	 * @return the username
	 */
	public String getUsername() {
		return username;
	}


	/**
	 * @param username the username to set
	 */
	public void setUsername(String username) {
		this.username = username;
	}


	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}


	/**
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}


	/**
	 * @return the errorMessage
	 */
	public String getErrorMessage() {
		return errorMessage;
	}

	/**
	 * @param errorMessage the errorMessage to set
	 */
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	/**
	 * @return the oldPassword
	 */
	public String getOldPassword() {
		return oldPassword;
	}
	/**
	 * @param oldPassword the oldPassword to set
	 */
	public void setOldPassword(String oldPassword) {
		this.oldPassword = oldPassword;
	}
	/**
	 * @return the newPassword
	 */
	public String getNewPassword() {
		return newPassword;
	}
	/**
	 * @param newPassword the newPassword to set
	 */
	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}
	

}
