package com.cg.discover.ets.action;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.ServletActionContext;

import com.cg.discover.ets.entity.Task;
import com.cg.discover.ets.entity.TaskTime;
import com.cg.discover.ets.entity.Track;
import com.cg.discover.ets.exception.ETSException;
import com.cg.discover.ets.service.TaskService;
import com.cg.discover.ets.service.TaskServiceImpl;
import com.cg.discover.ets.service.TrackService;
import com.cg.discover.ets.service.TrackServiceImpl;
import com.cg.discover.ets.service.UsersDetailService;
import com.cg.discover.ets.service.UsersDetailServiceImpl;
import com.cg.discover.ets.utility.DateUtils;
import com.cg.discover.ets.utility.Utils;
import com.cg.discover.ets.vo.DateVO;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

@SuppressWarnings("serial")
public class EffortTrackingAction extends ActionSupport {
	
	TaskService taskService = new TaskServiceImpl();
	TrackService trackService = new TrackServiceImpl();
	UsersDetailService usersDetailService = new UsersDetailServiceImpl();
	Map<String,String> months = null;
	Map<String,String> years = new TreeMap<String,String>();
	List<DateVO> dateList = new ArrayList<DateVO>(); 
	List<Task> taskList = new ArrayList<Task>();
	List<Track> trackList = new ArrayList<Track>();
	String month = null;
	String year = null;
	String userName = null;
	String errorMessage = null;
	String bU = "BU";
	private Integer userId=null;
	
	
	public String addTrack(){
		@SuppressWarnings("rawtypes")
		Map session = (Map) ActionContext.getContext().get("session");
		userName = (String) session.get("userName");
		userId = (Integer) session.get("userId");
		if(userName == null){
			errorMessage = "Your Session has been expired Please login again";
			return "failure";
		}
		
		HttpServletRequest request = ServletActionContext.getRequest();
		try {
			taskList = taskService.getTasksForEffort();
		} catch (ETSException e) {
			e.printStackTrace();
		}
		
		List<Track> tracks = new ArrayList<Track>();
		int dateRange = Utils.getDateRange(month, year);
		for (int i = 1; i <= dateRange; i++) {
			Track track = new Track();
			String appendStr = "";
			if(i<10){
				appendStr = "0";
			}
			track.setTrackDate(appendStr+i);
			
			String trackId = request.getParameter(appendStr+i+"trackId");
			if(null != trackId){
				track.setTrackId(Integer.parseInt(trackId));
			}
			String taskDateStr = request.getParameter(appendStr+i);
			if(taskDateStr != null){
				track.setTaskDate(DateUtils.getDate(taskDateStr));
			}
			try {
				track.setBU(usersDetailService.getUser(userId).getBU());
			} catch (ETSException e) {
				errorMessage = e.getMessage();
				return "failure";
			}
			track.setUserName(userName);

			String total = request.getParameter(appendStr+i+"total");
			if(null != total && !"".equals(total)){
				//track.setTotal(Integer.parseInt(total));
				track.setTotal(Float.parseFloat(total));
				
			}
			
			Set<TaskTime> taskTimeList = null;
			if(taskList != null && taskList.size()!= 0){
				taskTimeList = new HashSet<TaskTime>();
				for (Task t : taskList) {
					TaskTime taskTime = new TaskTime();
					taskTime.setTask(t);
					String taskTimeId = request.getParameter(appendStr+i+t.getTaskId());
					if(null != taskTimeId && !"".equals(taskTimeId)){
						taskTime.setTaskTimeId(Integer.parseInt(taskTimeId));
					}
					String taskHourStr = request.getParameter(appendStr+i+t.getTaskName());
					if(null != taskHourStr && !"".equals(taskHourStr)){
						//taskTime.setTaskTimeHour(Integer.parseInt(taskHourStr));
						taskTime.setTaskTimeHour(Float.parseFloat(taskHourStr));
					}
					taskTimeList.add(taskTime);
					
				}
			}
			track.setTaskTimeSet(taskTimeList);
			tracks.add(track);
		}
		
		boolean isInsert;
		try {
			isInsert = trackService.addAndUpdateTrack(tracks);
		} catch (ETSException e) {
			errorMessage = e.getMessage();
			return "failure";
		}
		if(isInsert){
			try {
				trackList = trackService.getTrackListBySearchCriteria(userName,month,year);
			} catch (ETSException e) {
				errorMessage = e.getMessage();
				return "failure";
			}
			months = Utils.getMonthList();
			years = Utils.getYearList();
			dateList = Utils.getDateList(month, year);
			
			return "success";
		}else{
			return "failure";
		}
		
	}
	
	public String effortTracking() {
		@SuppressWarnings("rawtypes")
		Map session = (Map) ActionContext.getContext().get("session");
		userName = (String) session.get("userName");
		
		if(userName == null){
			errorMessage = "Your Session has been expired Please login again";
			return "failure";
		}
		
		year = ""+java.util.Calendar.getInstance().get(Calendar.YEAR) ;
		
		if(month == null){
			int monthInt = java.util.Calendar.getInstance().get(Calendar.MONTH) +1;
			if(monthInt >= 1 || monthInt <= 10){
				month = "0"+monthInt;
			}
			month = ""+monthInt;
		}
		try {
			taskList = taskService.getTasksForEffort();
		} catch (ETSException e) {
			errorMessage = e.getMessage();
			return "failure";
		}
		try {
			trackList = trackService.getTrackListBySearchCriteria(userName,month,year);
		} catch (ETSException e) {
			errorMessage = e.getMessage();
			return "failure";
		}
		
		months = Utils.getMonthList();
		years = Utils.getYearList();
		dateList = Utils.getDateList(month, year);
		
		return "success";
	}
	
	public String getTrackListUsingAjax() {
		@SuppressWarnings("rawtypes")
		Map session = (Map) ActionContext.getContext().get("session");
		userName = (String) session.get("userName");
	
		if(userName == null){
			errorMessage = "Your Session has been expired Please login again";
			return "failure";
		}
		
		try {
			taskList = taskService.getTasksForEffort();
		} catch (ETSException e) {
			errorMessage = e.getMessage();
			return "failure";
		}
		try {
			trackList = trackService.getTrackListBySearchCriteria(userName,month,year);
		} catch (ETSException e) {
			errorMessage = e.getMessage();
			return "failure";
		}
		
		months = Utils.getMonthList();
		years = Utils.getYearList();
		dateList = Utils.getDateList(month, year);
		return "success";
	}

	public Map<String, String> getYears() {
		return years;
	}

	public void setYears(Map<String, String> years) {
		this.years = years;
	}

	/**
	 * @return the months
	 */
	public Map<String, String> getMonths() {
		return months;
	}

	/**
	 * @param months the months to set
	 */
	public void setMonths(Map<String, String> months) {
		this.months = months;
	}

	public List<DateVO> getDateList() {
		return dateList;
	}

	public void setDateList(List<DateVO> dateList) {
		this.dateList = dateList;
	}

	public List<Task> getTaskList() {
		return taskList;
	}

	public void setTaskList(List<Task> taskList) {
		this.taskList = taskList;
	}

	/**
	 * @return the trackList
	 */
	public List<Track> getTrackList() {
		return trackList;
	}

	/**
	 * @param trackList the trackList to set
	 */
	public void setTrackList(List<Track> trackList) {
		this.trackList = trackList;
	}

	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * @param userName the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}

	/**
	 * @return the month
	 */
	public String getMonth() {
		return month;
	}

	/**
	 * @param month the month to set
	 */
	public void setMonth(String month) {
		this.month = month;
	}

	/**
	 * @return the year
	 */
	public String getYear() {
		return year;
	}

	/**
	 * @param year the year to set
	 */
	public void setYear(String year) {
		this.year = year;
	}

	/**
	 * @return the errorMessage
	 */
	public String getErrorMessage() {
		return errorMessage;
	}

	/**
	 * @param errorMessage the errorMessage to set
	 */
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	
}
