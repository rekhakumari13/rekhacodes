package com.cg.discover.ets.action;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import com.cg.discover.ets.entity.Task;
import com.cg.discover.ets.entity.Track;
import com.cg.discover.ets.entity.User;
import com.cg.discover.ets.exception.ETSException;
import com.cg.discover.ets.service.TaskService;
import com.cg.discover.ets.service.TaskServiceImpl;
import com.cg.discover.ets.service.TrackService;
import com.cg.discover.ets.service.TrackServiceImpl;
import com.cg.discover.ets.service.UsersServiceImpl;
import com.cg.discover.ets.utility.Utils;
import com.cg.discover.ets.vo.DateVO;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

@SuppressWarnings("serial")
public class UserListAction extends ActionSupport {
	private String userName;
	UsersServiceImpl userServiceImpl = new UsersServiceImpl();
	List<User> userList = new ArrayList<User>();
	String errorMessage = null;
	TaskService taskService = new TaskServiceImpl();
	TrackService trackService = new TrackServiceImpl();
	Map<String,String> months = null;
	Map<String,String> years = new TreeMap<String,String>();
	List<DateVO> dateList = new ArrayList<DateVO>(); 
	List<Task> taskList = new ArrayList<Task>();
	List<Track> trackList = new ArrayList<Track>();
	String month = null;
	String year = null;
	String bU = "BU";
	String userNameSel = null;

	public String selectUser() {
		System.out.println("I am in action");
		System.out.println("userSelected Name =" + userName);
		try {
			taskList = taskService.getTasksForSelectedUser(userName);
			System.out.println("TASK LIST"+taskList);
			trackList = trackService.getTrackListBySearchCriteria(userName,month,year);
			userList = userServiceImpl.getUsers();
			Collections.sort(userList);
		} catch (ETSException e) {
			errorMessage = e.getMessage();
			return "failure";
		}
		
		months = Utils.getMonthList();
		years = Utils.getYearList();
		dateList = Utils.getDateList(month, year);
		userNameSel = userName;
		return "success";
	}
	public String userEffortTracking() {
		
		@SuppressWarnings("rawtypes")
		Map session = (Map) ActionContext.getContext().get("session");
		userName = (String) session.get("userName");
		System.out.println("UserName is***"+userName);
		
		if(userName == null){
			errorMessage = "Your Session has been expired Please login again";
			return "failure";
		}
		
		year = ""+java.util.Calendar.getInstance().get(Calendar.YEAR) ;
		
		if(month == null){
			int monthInt = java.util.Calendar.getInstance().get(Calendar.MONTH) +1;
			if(monthInt >= 1 || monthInt <= 10){
				month = "0"+monthInt;
			}
			month = ""+monthInt;
		}
		try {
			userList = userServiceImpl.getUsers();
			taskList = taskService.getTasksForEffort();
			trackList = trackService.getTrackListBySearchCriteria(userName,month,year);
			Collections.sort(userList);
		} catch (ETSException e) {
			errorMessage = e.getMessage();
			return "failure";
		}
		
		months = Utils.getMonthList();
		years = Utils.getYearList();
		dateList = Utils.getDateList(month, year);
		userNameSel = userName;
		
		return "success";
	}
	
	/**
	 * @return the userNameSel
	 */
	public String getUserNameSel() {
		return userNameSel;
	}
	/**
	 * @param userNameSel the userNameSel to set
	 */
	public void setUserNameSel(String userNameSel) {
		this.userNameSel = userNameSel;
	}
	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}


	/**
	 * @param userName the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}


	/**
	 * @return the user
	 */
	public List<User> getUserList() {
		return userList;
	}


	/**
	 * @param user the user to set
	 */
	public void setUserList(List<User> userList) {
		this.userList = userList;
	}


	/**
	 * @return the months
	 */
	public Map<String, String> getMonths() {
		return months;
	}

	/**
	 * @param months the months to set
	 */
	public void setMonths(Map<String, String> months) {
		this.months = months;
	}

	/**
	 * @return the years
	 */
	public Map<String, String> getYears() {
		return years;
	}

	/**
	 * @param years the years to set
	 */
	public void setYears(Map<String, String> years) {
		this.years = years;
	}

	/**
	 * @return the dateList
	 */
	public List<DateVO> getDateList() {
		return dateList;
	}

	/**
	 * @param dateList the dateList to set
	 */
	public void setDateList(List<DateVO> dateList) {
		this.dateList = dateList;
	}

	/**
	 * @return the taskList
	 */
	public List<Task> getTaskList() {
		return taskList;
	}

	/**
	 * @param taskList the taskList to set
	 */
	public void setTaskList(List<Task> taskList) {
		this.taskList = taskList;
	}

	/**
	 * @return the trackList
	 */
	public List<Track> getTrackList() {
		return trackList;
	}

	/**
	 * @param trackList the trackList to set
	 */
	public void setTrackList(List<Track> trackList) {
		this.trackList = trackList;
	}

	/**
	 * @return the month
	 */
	public String getMonth() {
		return month;
	}

	/**
	 * @param month the month to set
	 */
	public void setMonth(String month) {
		this.month = month;
	}

	/**
	 * @return the year
	 */
	public String getYear() {
		return year;
	}

	/**
	 * @param year the year to set
	 */
	public void setYear(String year) {
		this.year = year;
	}

	/**
	 * @return the errorMessage
	 */
	public String getErrorMessage() {
		return errorMessage;
	}


	/**
	 * @param errorMessage the errorMessage to set
	 */
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

}
