package com.cg.discover.ets.action;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.cg.discover.ets.dao.LoginDAO;
import com.cg.discover.ets.dao.LoginDAOImpl;
import com.cg.discover.ets.entity.BU;
import com.cg.discover.ets.entity.Task;
import com.cg.discover.ets.entity.UserLogin;
import com.cg.discover.ets.exception.ETSException;
import com.cg.discover.ets.service.BuServiceImpl;
import com.cg.discover.ets.service.TaskServiceImpl;
import com.cg.discover.ets.service.UsersDetailService;
import com.cg.discover.ets.service.UsersDetailServiceImpl;
import com.cg.discover.ets.vo.TaskList;
import com.cg.discover.ets.vo.TaskListUpdate;
import com.cg.discover.ets.vo.UsersReport;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

@SuppressWarnings("serial")
public class TaskAction extends ActionSupport {
	TaskServiceImpl taskServiceImpl = new TaskServiceImpl();
	private Integer taskId;
	private Integer BUId;
	private String taskName;
	private String taskDescription;
	private BU BU;
	UsersDetailService usersDetailService = new UsersDetailServiceImpl();
	BuServiceImpl buServiceImpl = new BuServiceImpl();
	List<TaskList> taskList = new ArrayList<TaskList>();
	List<TaskListUpdate> taskListUpdate = new ArrayList<TaskListUpdate>();
	List<BU> buList = new ArrayList<BU>();
	UserLogin userList;
	LoginDAO loginDao = new LoginDAOImpl();
	String userName = null;
	String errorMessage = null;
	
	public String addTask() {
		
		@SuppressWarnings("rawtypes")
		Map session = (Map) ActionContext.getContext().get("session");
		userName = (String) session.get("userName");
		if(userName == null){
			errorMessage = "Your Session has been expired Please login again";
			return "failure";
		}
		int isInsert = 0;
		try {
			System.out.println("Chaitrali"+BUId);
			isInsert = taskServiceImpl.addAndUpdateTask(taskId,taskName,taskDescription,BUId);
			taskList = taskServiceImpl.getTasks();
		} catch (ETSException e) {
			errorMessage = e.getMessage();
			return "failure";
		}

		if(isInsert == 0){
			return "failure";
		}else{
			return "success";
		}
	}
	
	public String getTaskForUpdate() {
		
		@SuppressWarnings("rawtypes")
		Map session = (Map) ActionContext.getContext().get("session");
		userName = (String) session.get("userName");
		if(userName == null){
			errorMessage = "Your Session has been expired Please login again";
			return "failure";
		}
		try {
			taskList = taskServiceImpl.getTasks();
			//taskListUpdate = taskServiceImpl.getTask(taskId);
			List<TaskListUpdate> task = taskServiceImpl.getTask(taskId);
			if(task.size() > 0){
				buList = buServiceImpl.getBUList();
				/*BU= new BU();
				BU.setBU(task.get(0).getBU());
				BU.setBUId(task.get(0).getBUId());*/
				BUId = task.get(0).getBUId();
				taskName=task.get(0).getTaskName();
				taskDescription=task.get(0).getTaskDescription();
			}
			//TaskListUpdate task = (TaskListUpdate) taskServiceImpl.getTask(taskId);
			//taskName = task.getTaskName();
			//taskDescription = task.getTaskDescription();
		} catch (ETSException e) {
			errorMessage = e.getMessage();
			return "failure";
		}
		return "success";
	}
	
	public String deleteTask() {
		
		@SuppressWarnings("rawtypes")
		Map session = (Map) ActionContext.getContext().get("session");
		userName = (String) session.get("userName");
		if(userName == null){
			errorMessage = "Your Session has been expired Please login again";
			return "failure";
		}
		System.out.println("taskId =" + taskId);	
		
		int isDelete = 0;
		try {
			isDelete = taskServiceImpl.deleteTask(taskId);
		} catch (ETSException e) {
			errorMessage = e.getMessage();
			addActionError(errorMessage);
			return "failure";
		}
		
		if(isDelete == 0){
			return "failure";
		}else{
			return "success";
		}
		
	}
	
	public String getTasks() {
		
		@SuppressWarnings("rawtypes")
		Map session = (Map) ActionContext.getContext().get("session");
		userName = (String) session.get("userName");
		if(userName == null){
			errorMessage = "Your Session has been expired Please login again";
			return "failure";
		}
		try {
			
		/*	List<UserLogin> usersReport= userList ;*/
			buList = buServiceImpl.getBUList();
			userList=loginDao.loginDAO(userName);
			System.out.println(userList);
			System.out.println(userList.getBU());
			taskList = taskServiceImpl.getTasks();
		} catch (ETSException e) {
			errorMessage = e.getMessage();
			return "failure";
		}
		return "success";
	}

	public UserLogin getUserList() {
		return userList;
	}

	public void setUserList(UserLogin userList) {
		this.userList = userList;
	}

	public String getTaskName() {
		return taskName;
	}

	public Integer getTaskId() {
		return taskId;
	}

	public void setTaskId(Integer taskId) {
		this.taskId = taskId;
	}

	public String getTaskDescription() {
		return taskDescription;
	}

	public void setTaskDescription(String taskDescription) {
		this.taskDescription = taskDescription;
	}

	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}

	public List<TaskList> getTaskList() {
		return taskList;
	}

	public void setTaskList(List<TaskList> taskList) {
		this.taskList = taskList;
	}

	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * @param userName the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}
	

	/**
	 * @return the errorMessage
	 */
	public String getErrorMessage() {
		return errorMessage;
	}

	/**
	 * @param errorMessage the errorMessage to set
	 */
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public Integer getBUId() {
		return BUId;
	}

	public void setBUId(Integer bUId) {
		BUId = bUId;
	}

	public List<BU> getBuList() {
		return buList;
	}

	public void setBuList(List<BU> buList) {
		this.buList = buList;
	}

	public List<TaskListUpdate> getTaskListUpdate() {
		return taskListUpdate;
	}

	public void setTaskListUpdate(List<TaskListUpdate> taskListUpdate) {
		this.taskListUpdate = taskListUpdate;
	}

	public BU getBU() {
		return BU;
	}

	public void setBU(BU bU) {
		BU = bU;
	}

	
}
