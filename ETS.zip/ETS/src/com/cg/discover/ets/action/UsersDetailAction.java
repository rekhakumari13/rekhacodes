package com.cg.discover.ets.action;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.cg.discover.ets.entity.BU;
import com.cg.discover.ets.entity.Team;
import com.cg.discover.ets.entity.UserLogin;
import com.cg.discover.ets.exception.ETSException;
import com.cg.discover.ets.service.BuServiceImpl;
import com.cg.discover.ets.service.TeamNameServiceImpl;
import com.cg.discover.ets.service.UsersDetailService;
import com.cg.discover.ets.service.UsersDetailServiceImpl;
import com.opensymphony.xwork2.ActionSupport;

@SuppressWarnings("serial")
public class UsersDetailAction extends ActionSupport {
	UsersDetailService usersDetailService = new UsersDetailServiceImpl();
	BuServiceImpl buServiceImpl = new BuServiceImpl();
	TeamNameServiceImpl teamNameServiceImpl = new TeamNameServiceImpl();
	
	private String userName;
	private String password;
	private String employeeName;
	private String employeeID;
	private BU BU;
	private Integer BUId;
	private Integer userId;
	private Team teamName;
	private String buName;
	private String teamNameEdit;
	private Integer teamNameId;
	private String emailID;
	private Boolean isAdmin;
	List<UserLogin> userList = new ArrayList<UserLogin>();
	List<BU> buList = new ArrayList<BU>();
	Set<Team> teamNameList = new HashSet<Team>();
	String errorMessage = null;
	
	public String addUser() {
		
		int isInsert = 0;
		try {
			isInsert = usersDetailService.addAndUpdateUser(userId,userName,password,employeeName,employeeID,BUId,teamNameId,emailID,isAdmin);
			userList = usersDetailService.getUsers();
		} catch (ETSException e) {
			errorMessage = e.getMessage();
			return "failure";
		}

		if(isInsert == 0){
			return "failure";
		}else{
			return "success";
		}
	}
	
	public String getUserForUpdate() {
		
		try {
			userList = usersDetailService.getUsers();
			buList = buServiceImpl.getBUList();
			teamNameList=teamNameServiceImpl.getTeamNameList();
			UserLogin user = usersDetailService.getUser(userId);
			userId=user.getUserId();
			userName = user.getUserName();
			password = user.getPassword();
			employeeName = user.getEmployeeName();
			employeeID = user.getEmployeeID();
			//BU = user.getBU();
			//teamName = user.getTeam();
			buName=user.getBU().getBU();
			BUId = user.getBU().getBUId();
			teamNameId= user.getTeam().getTeamNameId();
			emailID = user.getEmailID();
			isAdmin = user.getIsAdmin();
		
		} catch (ETSException e) {
			errorMessage = e.getMessage();
			return "failure";
		}
		return "success";
	}
	
	public String deleteUser() {
		
		int isDelete = 0;
		try {
			isDelete = usersDetailService.deleteUser(userId);
		} catch (ETSException e) {
			errorMessage = e.getMessage();
			addActionError(errorMessage);
			return "failure";
		}
		
		if(isDelete == 0){
			return "failure";
		}else{
			return "success";
		}
		
	}
	
	public String getUsers() {
		
		try {
			userList = usersDetailService.getUsers();
			System.out.println("NITESH"+userList);
			buList = buServiceImpl.getBUList();
			teamNameList=teamNameServiceImpl.getTeamNameList();
		} catch (ETSException e) {
			errorMessage = e.getMessage();
			return "failure";
		}
		return "success";
	}

	 public String getTeamNameForUserAdding() {
		 buList = null;
		 teamNameList = null;
		 userList = null;
		try {
			userList = usersDetailService.getUsers();
			System.out.println("NITESH"+userList);
			buList = buServiceImpl.getBUList();
			teamNameList = teamNameServiceImpl.getTeamNamesById(BUId);
		} catch (ETSException e) {
			errorMessage = e.getMessage();
			return "failure";
		}
		return "success";
	}
	

	public BU getBU() {
		return BU;
	}

	public void setBU(BU bU) {
		BU = bU;
	}

	public Integer getBUId() {
		return BUId;
	}

	public void setBUId(Integer bUId) {
		BUId = bUId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getEmployeeID() {
		return employeeID;
	}

	public void setEmployeeID(String employeeID) {
		this.employeeID = employeeID;
	}

	public Integer getBUid() {
		return BUId;
	}

	public void setBUid(Integer bUid) {
		BUId = bUid;
	}


	public Team getTeamName() {
		return teamName;
	}

	public void setTeamName(Team teamName) {
		this.teamName = teamName;
	}

	public Integer getTeamNameId() {
		return teamNameId;
	}

	public void setTeamNameId(Integer teamNameId) {
		this.teamNameId = teamNameId;
	}

	
	public Set<Team> getTeamNameList() {
		return teamNameList;
	}

	public void setTeamNameList(Set<Team> teamNameList) {
		this.teamNameList = teamNameList;
	}

	public String getEmailID() {
		return emailID;
	}

	public void setEmailID(String emailID) {
		this.emailID = emailID;
	}

	public Boolean getIsAdmin() {
		return isAdmin;
	}

	public void setIsAdmin(Boolean isAdmin) {
		this.isAdmin = isAdmin;
	}

	public List<UserLogin> getUserList() {
		return userList;
	}

	public void setUserList(List<UserLogin> userList) {
		this.userList = userList;
	}

	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * @param userName the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}

	/**
	 * @return the errorMessage
	 */
	public String getErrorMessage() {
		return errorMessage;
	}

	/**
	 * @param errorMessage the errorMessage to set
	 */
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	/**
	 * @return the buList
	 */
	public List<BU> getBuList() {
		return buList;
	}

	public String getBuName() {
		return buName;
	}

	public void setBuName(String buName) {
		this.buName = buName;
	}

	public String getTeamNameEdit() {
		return teamNameEdit;
	}

	public void setTeamNameEdit(String teamNameEdit) {
		this.teamNameEdit = teamNameEdit;
	}

	/**
	 * @param buList the buList to set
	 */
	public void setBuList(List<BU> buList) {
		this.buList = buList;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	
}
