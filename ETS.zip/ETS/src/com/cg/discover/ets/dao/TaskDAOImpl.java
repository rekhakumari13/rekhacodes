package com.cg.discover.ets.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.cg.discover.ets.utility.DateUtils;
import com.cg.discover.ets.utility.HibernateUtil;
import com.cg.discover.ets.vo.TaskList;
import com.cg.discover.ets.vo.TaskListUpdate;
import com.cg.discover.ets.vo.UsersReport;

import org.hibernate.Session;
import org.hibernate.Transaction;





import com.cg.discover.ets.entity.BU;
import com.cg.discover.ets.entity.Task;
import com.cg.discover.ets.entity.Track;
import com.cg.discover.ets.entity.UserLogin;
import com.cg.discover.ets.exception.ETSException;
import com.opensymphony.xwork2.ActionContext;

public class TaskDAOImpl implements TaskDAO {

	private Integer BUId;
	@Override
	public int addAndUpdateTask(Task task) throws ETSException {
		Integer isInsert = 1;
		Session session = HibernateUtil.getInstance().openSession();
		Transaction tx= session.beginTransaction();
		try {
			tx.begin();
			session.merge(task);
			tx.commit();
		} catch (Exception e) {
			isInsert = 0;
			tx.rollback();
			throw new ETSException("Exception when add/update the task: "+e.getMessage());
		}
		 finally {
	        	session.close();
	        }	
		return isInsert;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<TaskList> getTasks() throws ETSException {
		@SuppressWarnings("rawtypes")
		Map loginSession = (Map) ActionContext.getContext().get("session");
		BUId = (Integer) loginSession.get("BUId");
		System.out.println("BUId is****"+BUId);
		Session session = HibernateUtil.getInstance().openSession();
		String sql =null;
			if(BUId==1){
				sql = "from Task t,BU b where t.BUId = b.BUId order by t.BUId, t.taskName";
			}
			else{
				sql = "from Task t,BU b where t.BUId = b.BUId and t.BUId='"+BUId+"'  order by t.BUId, t.taskName";
			}
			System.out.println("QUERY is"+sql);
			List<Object[]> objArr = session.createQuery(sql).list();
			List<TaskList> tasks = new  ArrayList<TaskList>();
			
			for (Object[] o : objArr) {
				TaskList taskList = new TaskList();
				Task task = (Task)o[0];
				BU bu = (BU)o[1];
				if(task.getTaskId() != null)
				taskList.setBU(bu.getBU());
				taskList.setTaskId(task.getTaskId());
				taskList.setBUId(task.getBUId());
				taskList.setTaskName(task.getTaskName());
				taskList.setTaskDescription(task.getTaskDescription());
				
				tasks.add(taskList);
			}
		return tasks;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<TaskListUpdate> getTask(int taskId) throws ETSException {
		@SuppressWarnings("rawtypes")
		Map loginSession = (Map) ActionContext.getContext().get("session");
		BUId = (Integer) loginSession.get("BUId");
		System.out.println("BUId is****"+BUId);
		Session session = HibernateUtil.getInstance().openSession();
		String sql =null;
			if(BUId==1){
				sql = "from Task t,BU b where t.BUId = b.BUId and t.taskId='"+taskId+"' order by t.BUId, t.taskName";
			}
			else{
				sql = "from Task t,BU b where t.BUId = b.BUId and t.BUId='"+BUId+"' and t.taskId='"+taskId+"' order by t.BUId, t.taskName";
			}
			System.out.println("QUERY is"+sql);
			List<Object[]> objArr = session.createQuery(sql).list();
			List<TaskListUpdate> tasks = new  ArrayList<TaskListUpdate>();
			
			for (Object[] o : objArr) {
				TaskListUpdate taskListUpdate = new TaskListUpdate();
				Task task = (Task)o[0];
				BU bu = (BU)o[1];
				if(task.getTaskId() != null)
				taskListUpdate.setBU(bu.getBU());
				taskListUpdate.setTaskId(task.getTaskId());
				taskListUpdate.setBUId(task.getBUId());
				taskListUpdate.setTaskName(task.getTaskName());
				taskListUpdate.setTaskDescription(task.getTaskDescription());
				
				tasks.add(taskListUpdate);
			}
		return tasks;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Task> getTasksForEffort() throws ETSException {
		List<Task> tasks = null;
		@SuppressWarnings("rawtypes")
		Map loginSession = (Map) ActionContext.getContext().get("session");
		BUId = (Integer) loginSession.get("BUId");
		System.out.println("BUId is****"+BUId);
		Session session = HibernateUtil.getInstance().openSession();
		try {
			tasks = session.createQuery("from Task t where t.BUId='"+BUId+"'  order by t.taskId").list();
			
		} catch (Exception e) {
			throw new ETSException("Exception when getting the task list: "+e.getMessage());
		}
		 finally {
	        	//session.close();
	        }
		return tasks;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Task> getTasksForSelectedUser(String userName) throws ETSException{
		Integer buId=null;
		List<UserLogin> userLogins =null;
		List<Task> tasks = null;
		Session session = HibernateUtil.getInstance().openSession();
		try {
			userLogins = session.createQuery("from UserLogin where user_name = '" + userName + "'").list();
			System.out.println("NITESH"+userLogins);
			if (userLogins.size() != 0)
			{
				buId=userLogins.get(0).getBU().getBUId();
				System.out.println("****"+buId);	
			}
			tasks = session.createQuery("from Task t where t.BUId='"+buId+"'  order by t.taskId").list();
			
		} catch (Exception e) {
			throw new ETSException("Exception when getting the task list: "+e.getMessage());
		}
		 finally {
	        	//session.close();
	        }
		return tasks;
	}
	
/*	@Override
	public Task getTask(int taskId) throws ETSException{
		Task task = null;
		Session session = HibernateUtil.getInstance().openSession();
		try {
			Task temp = (Task) session.get(Task.class, taskId);
			task = temp;
		} catch (Exception e) {
			throw new ETSException("Exception when getting the task: "+e.getMessage());
		}
		 finally {
	        	session.close();
	        }
		return task;
	}
*/
	@Override
	public int deleteTask(int taskId) throws ETSException {
		Integer isDelete = 1;
		Session session = HibernateUtil.getInstance().openSession();
		Transaction tx= session.beginTransaction();
		try {
			tx.begin();
			Task task = (Task) session.get(Task.class, taskId);
			session.delete(task);
			tx.commit();
		} catch (Exception e) {
			isDelete = 0;
			tx.rollback();
			throw new ETSException("Exception when deleting the task: "+e.getMessage());
		}
		 finally {
	        	session.close();
	        }
		return isDelete;
	}
}
