package com.cg.discover.ets.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.cg.discover.ets.entity.UserLogin;
import com.cg.discover.ets.exception.ETSException;
import com.cg.discover.ets.utility.HibernateUtil;

public class LoginDAOImpl implements LoginDAO {

	public UserLogin loginDAO(String userName) throws ETSException {

		UserLogin userLogin= null;
		Session session = HibernateUtil.getInstance().openSession();
		try {
			@SuppressWarnings("unchecked")
			List<UserLogin> userLogins = session.createQuery("from UserLogin where user_name = '" + userName + "'").list();
			if (userLogins.size() != 0)
				userLogin = (UserLogin) userLogins.get(0);
		} catch (Exception e) {
			throw new ETSException("Problem with login user: "+e.getMessage());
		}
		/* finally {
	        	session.close();
	        }*/
		System.out.println("******"+userLogin);
		return userLogin;
	}

	@Override
	public boolean changePassword(UserLogin userLogin) throws ETSException {

		boolean isInsert = true;
		Session session = HibernateUtil.getInstance().openSession();
		Transaction tx= session.beginTransaction();
		tx.begin();
		try {
			session.merge(userLogin);
			tx.commit();
		} catch (Exception e) {
			isInsert = false;
			tx.rollback();
			throw new ETSException("Exception when update the password: "
					+ e.getMessage());
		} 
		 finally {
	        	session.close();
	        }
		return isInsert;

	}

}
