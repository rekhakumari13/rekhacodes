package com.cg.discover.ets.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;

import com.cg.discover.ets.entity.User;
import com.cg.discover.ets.entity.UserLogin;
import com.cg.discover.ets.exception.ETSException;
import com.cg.discover.ets.utility.HibernateUtil;
import com.opensymphony.xwork2.ActionContext;

public class UserDAOImpl implements UserDAO {
	private Integer BUId;

	@SuppressWarnings("unchecked")
	@Override
	public List<User> getUsers() throws ETSException {
		List<UserLogin> userList = null;
		List<User> users = null;
		@SuppressWarnings("rawtypes")
		Map loginSession = (Map) ActionContext.getContext().get("session");
		BUId = (Integer) loginSession.get("BUId");
		System.out.println("BUId is****"+BUId);
		Session session = HibernateUtil.getInstance().openSession();
		try {
			if(BUId==1){
			userList = session.createQuery("from UserLogin u").list();
			}
			else{
			userList = session.createQuery("from UserLogin u where u.BU.BUId='"+BUId+"'").list();
			}
			if(null != userList && userList.size() != 0){
				users = new ArrayList<User>();
				for (UserLogin userLogin : userList) {
					User user = new User();
					user.setUserName(userLogin.getUserName());
					user.setEmployeeName(userLogin.getEmployeeName());
					users.add(user);
				}
			}
		} catch (Exception e) {
			throw new ETSException("Exception when getting the user list: "+e.getMessage());
		}
		 finally {
	        	session.close();
	        }
		return users;
	}

}
