package com.cg.discover.ets.dao;

import java.util.List;

import com.cg.discover.ets.entity.Track;
import com.cg.discover.ets.exception.ETSException;

public interface TrackDAO {
	public boolean addAndUpdateTrack(List<Track> trackList) throws ETSException;
	public List<Track> getTrackListBySearchCriteria(String userName,String month,String year) throws ETSException;
    }
