package com.cg.discover.ets.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;

import com.cg.discover.ets.entity.Track;
import com.cg.discover.ets.entity.UserLogin;
import com.cg.discover.ets.excelcreater.ExcelCreator;
import com.cg.discover.ets.exception.ETSException;
import com.cg.discover.ets.utility.DateUtils;
import com.cg.discover.ets.utility.HibernateUtil;
import com.cg.discover.ets.vo.UserSearch;
import com.cg.discover.ets.vo.UsersReport;
import com.opensymphony.xwork2.ActionContext;

public class UsersReportDaoImpl implements UsersReportDao {

	@Override
	public List<UsersReport> gerUsersReport(UserSearch userSearch) throws ETSException {
		
		@SuppressWarnings("rawtypes")
		Map loginSession = (Map) ActionContext.getContext().get("session");
		Integer BUIdd = (Integer) loginSession.get("BUId");
		System.out.println("BUId is****"+BUIdd);
		Session session = HibernateUtil.getInstance().openSession();
		System.out.println("*********"+userSearch.getFromDate());
		System.out.println("*********"+userSearch.getToDate());
		System.out.println("*********"+userSearch.getBuName());
		System.out.println("*********"+userSearch.getTeamName());
		System.out.println("*********"+userSearch.getAssociateName());
		//List<Object[]> objArr = session.createQuery("from UserLogin u, Track tr where u.userName = tr.userName and tr.taskDate between '"+userSearch.getFromDate()+"' and '"+userSearch.getToDate()+"' order by tr.taskDate").list();
		//List<Object[]> objArr = session.createQuery("from UserLogin u, Track tr where u.userName = tr.userName and tr.taskDate between '"+userSearch.getFromDate()+"' and '"+userSearch.getToDate()+"' and u.BU.BUId ='"+userSearch.getBuName()+"' and u.team.teamNameId ='"+userSearch.getTeamName()+"' and u.userName='"+userSearch.getAssociateName()+"' order by tr.taskDate").list();
		
		String sql = "from UserLogin u, Track tr where u.userName = tr.userName and tr.taskDate between '"+userSearch.getFromDate()+"' and '"+userSearch.getToDate()+"'";
		if(BUIdd==1){
		if(null != userSearch.getBuName() && !"0".equals(userSearch.getBuName())){
			sql = sql + " and u.BU.BUId ='"+userSearch.getBuName()+"' ";
		}
		}
		else{
			sql = sql + " and u.BU.BUId ='"+BUIdd+"' ";
				
		}
		if(userSearch.getTeamName() != null && !"0".equals(userSearch.getTeamName())){
			sql = sql + " and u.team.teamNameId ='"+userSearch.getTeamName()+"' ";
		}
		
		if(userSearch.getAssociateName() != null && !"0".equals(userSearch.getAssociateName())){
			sql = sql + " and u.userName='"+userSearch.getAssociateName()+"' ";
		}
		sql = sql + " order by u.BU.BU,u.team.teamName,u.userName,tr.taskDate ";
		System.out.println("QUERY is"+sql);
		List<Object[]> objArr = session.createQuery(sql).list();
		
		List<UsersReport> usersReportList = new  ArrayList<UsersReport>();
		for (Object[] o : objArr) {
			UsersReport report = new UsersReport();
			UserLogin userLogin = (UserLogin)o[0];
			Track track = (Track)o[1];
			if(track.getBU() != null)
			report.setBuName(track.getBU().getBU());
			report.setEmployeeName(userLogin.getEmployeeName());
			if(track.getTaskDate() != null)
			report.setTaskDate(DateUtils.getFormattedDateMonthYear(track.getTaskDate()));
			report.setTaskTimeSet(track.getTaskTimeSet());
			report.setTeamName(userLogin.getTeam().getTeamName());
			if(track.getTotal() != null)
			report.setTotal(track.getTotal().toString());
			usersReportList.add(report);
		}
		System.out.println(usersReportList);
		try {
			//ExcelCreator.createWorkbook(usersReportList);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return usersReportList;
	}
	

}
