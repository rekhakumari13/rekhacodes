package com.cg.discover.ets.dao;

import java.util.List;

import com.cg.discover.ets.entity.User;
import com.cg.discover.ets.exception.ETSException;

public interface UserDAO {
	
	public List<User> getUsers() throws ETSException;
}
