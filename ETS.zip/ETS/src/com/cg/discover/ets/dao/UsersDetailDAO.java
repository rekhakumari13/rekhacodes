package com.cg.discover.ets.dao;

import java.util.List;

import com.cg.discover.ets.entity.UserLogin;
import com.cg.discover.ets.exception.ETSException;

public interface UsersDetailDAO {
	public int addAndUpdateUser(UserLogin user) throws ETSException;
	public int deleteUser(Integer userId) throws ETSException;
	public List<UserLogin> getUsers() throws ETSException;
    public UserLogin getUser(Integer userId) throws ETSException;
}
