package com.cg.discover.ets.dao;
import com.cg.discover.ets.entity.UserLogin;
import com.cg.discover.ets.exception.ETSException;

public interface LoginDAO {
	public  UserLogin loginDAO(String userName) throws ETSException;
	public  boolean changePassword(UserLogin userLogin) throws ETSException;

}
