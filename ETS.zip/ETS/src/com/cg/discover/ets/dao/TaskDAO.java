package com.cg.discover.ets.dao;

import java.util.List;

import com.cg.discover.ets.entity.Task;
import com.cg.discover.ets.exception.ETSException;
import com.cg.discover.ets.vo.TaskList;
import com.cg.discover.ets.vo.TaskListUpdate;

public interface TaskDAO {
	public int addAndUpdateTask(Task task) throws ETSException;
	public int deleteTask(int taskId) throws ETSException;
	public List<TaskList> getTasks() throws ETSException;
	public List<TaskListUpdate> getTask(int taskId) throws ETSException;
    //public Task getTask(int taskId) throws ETSException;
    public List<Task> getTasksForEffort() throws ETSException;
    public List<Task> getTasksForSelectedUser(String userName) throws ETSException;
}
