package com.cg.discover.ets.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;




import com.cg.discover.ets.entity.Track;
import com.cg.discover.ets.entity.UserLogin;
import com.cg.discover.ets.exception.ETSException;
import com.cg.discover.ets.utility.HibernateUtil;

public class TrackDAOImpl implements TrackDAO {
	
	

	@Override
	public boolean addAndUpdateTrack(List<Track> trackList) throws ETSException {
		System.out.println("into Track");
		boolean isInsert = true;
		Session session = HibernateUtil.getInstance().openSession();
		System.out.println("session created"+session);
		Transaction tx= session.beginTransaction();
		tx.begin();
		try {
			for (Track track : trackList) {
				session.merge(track);
			}
			tx.commit();
		} catch (Exception e) {
			isInsert = false;
			tx.rollback();
			throw new ETSException("Exception when add/update the track: "
					+ e.getMessage());
		} 
		 finally {
	        	session.close();
	        }
		return isInsert;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Track> getTrackListBySearchCriteria(String userName,
			String trackMonth, String trackYear) throws ETSException {

		Integer buId=null;
		List<UserLogin> userLogins =null;
		List<Track> trackVOs = null;
		Session session = HibernateUtil.getInstance().openSession();
		System.out.println("NITESH SESSION"+session);
		try {
			userLogins = session.createQuery("from UserLogin where user_name = '" + userName + "'").list();
			System.out.println("NITESH"+userLogins);
			if (userLogins.size() != 0)
			{
				buId=userLogins.get(0).getBU().getBUId();
				System.out.println("****"+buId);
				
			}
			trackVOs = session.createQuery(
					"from Track t where t.userName= '" + userName
					        + "' and t.BU.BUId = '" + buId
							+ "' and month(t.taskDate) = '" + trackMonth
							+ "' and year(t.taskDate) = '" + trackYear
							+ "' order by t.trackDate").list();
			System.out.println("TRACK"+trackVOs);
			
		} catch (Exception e) {
			throw new ETSException(
					"Exception when getting the track by search criteria: "
							+ e.getMessage());
		} 
		 finally {
	        	session.disconnect();
	        	session.flush();
	        	System.out.println("NITESH SESSION CLOSED"+session);
	        }
		return trackVOs;
	}

}
