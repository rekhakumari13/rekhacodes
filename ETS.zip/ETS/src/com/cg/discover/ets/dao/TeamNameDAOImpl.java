package com.cg.discover.ets.dao;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.hibernate.Session;

import com.cg.discover.ets.entity.Team;
import com.cg.discover.ets.entity.UserLogin;
import com.cg.discover.ets.exception.ETSException;
import com.cg.discover.ets.utility.HibernateUtil;
import com.opensymphony.xwork2.ActionContext;

public class TeamNameDAOImpl implements TeamNameDAO {

	private Integer BUId;
	@SuppressWarnings("unchecked")
	@Override
	public Set<Team> getTeamNameList() throws ETSException {
		List<Team> teamnamelist = null;
		Set<Team> teamSet = new HashSet<Team>();
		@SuppressWarnings("rawtypes")
		Map loginSession = (Map) ActionContext.getContext().get("session");
		BUId = (Integer) loginSession.get("BUId");
		System.out.println("BUId is****"+BUId);
		Session session = HibernateUtil.getInstance().openSession();
		try {
			if(BUId==1){
			teamnamelist = session.createQuery("from Team t order by t.teamNameId").list();
			}
			else{
			teamnamelist = session.createQuery("from Team t where t.BUId='"+BUId+"' order by t.teamNameId").list();
			}
			teamSet.addAll(teamnamelist);
		} catch (Exception e) {
			throw new ETSException("Exception when getting the Team list: "+e.getMessage());
		}
		 finally {
	        	session.close();
	        }
		return teamSet;
	}
	
	@Override
	public Team getTeamName(Integer teamNameId) throws ETSException {
		Team teamname  = null;
		Session session = HibernateUtil.getInstance().openSession();
		try {
			teamname = (Team) session.createQuery("from Team t where t.teamNameId = "+teamNameId).list().get(0);
			
		} catch (Exception e) {
			throw new ETSException("Exception when getting the Team : "+e.getMessage());
		}
		 finally {
	        	session.close();
	        }
		return teamname;
	}
	@Override
	public Set<Team> getTeamNamesById(Integer bUId) throws ETSException {
		List<UserLogin> userList  = null;
		Session session = HibernateUtil.getInstance().openSession();
		Set<Team> teamSet = new HashSet<Team>();
		try {
			userList =  (List<UserLogin>) session.createQuery("from UserLogin u where u.BU.BUId = "+bUId).list();
			for (UserLogin user : userList) {
				teamSet.add(user.getTeam());
			}
			System.out.println(teamSet);
		} catch (Exception e) {
			throw new ETSException("Exception when getting the Team : "+e.getMessage());
		}
		 finally {
	        	session.close();
	        }
		return teamSet;
	}
	
	@Override
	public List<UserLogin> getEmployeesName(String teamId, Integer BUId) throws ETSException {
		List<UserLogin> employeeList  = null;
		
		@SuppressWarnings("rawtypes")
		Map loginSession = (Map) ActionContext.getContext().get("session");
		Integer BUIdd = (Integer) loginSession.get("BUId");
		System.out.println("BUId is****"+BUIdd);
		
		
		Session session = HibernateUtil.getInstance().openSession();
		try {
			if(BUIdd==1){
			String sql = "from UserLogin u where 1 = 1 ";
			if(null != BUId && !"0".equals(BUId)){
				sql = sql + " and u.BU.BUId = "+BUId+" ";
			}
			
			if(teamId != null && !"0".equals(teamId)){
				sql = sql + " and u.team.teamNameId = "+teamId;
			}
			employeeList =  (List<UserLogin>) session.createQuery(sql).list();
			}
			else{
				String sql = "from UserLogin u where 1 = 1 ";
				if(null != BUIdd && !"0".equals(BUIdd)){
					sql = sql + " and u.BU.BUId = "+BUIdd+" ";
				}
				
				if(teamId != null && !"0".equals(teamId)){
					sql = sql + " and u.team.teamNameId = "+teamId;
				}
				employeeList =  (List<UserLogin>) session.createQuery(sql).list();
			}
		} catch (Exception e) {
			throw new ETSException("Exception when getting the Team : "+e.getMessage());
		}
		 
		return employeeList;
	}
}
