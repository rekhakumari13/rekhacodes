package com.cg.discover.ets.dao;

import java.util.List;
import java.util.Set;

import com.cg.discover.ets.entity.Team;
import com.cg.discover.ets.entity.UserLogin;
import com.cg.discover.ets.exception.ETSException;

public interface TeamNameDAO {
	
	public Set<Team> getTeamNameList() throws ETSException;
	public Team getTeamName(Integer teamNameId) throws ETSException;
	public Set<Team> getTeamNamesById(Integer bUId)throws ETSException;
	public List<UserLogin> getEmployeesName(String teamId, Integer BUId)  throws ETSException;
}
