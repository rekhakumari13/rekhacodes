package com.cg.discover.ets.dao;

import java.util.List;

import com.cg.discover.ets.exception.ETSException;
import com.cg.discover.ets.vo.UserSearch;
import com.cg.discover.ets.vo.UsersReport;

public interface UsersReportDao {
	
	public List<UsersReport> gerUsersReport(UserSearch userSearch) throws ETSException; 
	
   
}
