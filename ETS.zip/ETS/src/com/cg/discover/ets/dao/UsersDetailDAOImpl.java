package com.cg.discover.ets.dao;

import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.cg.discover.ets.entity.UserLogin;
import com.cg.discover.ets.exception.ETSException;
import com.cg.discover.ets.utility.HibernateUtil;
import com.opensymphony.xwork2.ActionContext;

public class UsersDetailDAOImpl implements UsersDetailDAO {

	private Integer BUId;
	@Override
	public int addAndUpdateUser(UserLogin user) throws ETSException {
		Integer isInsert = 1;
		Session session = HibernateUtil.getInstance().openSession();
		Transaction tx= session.beginTransaction();
		try {
			tx.begin();
			
			session.merge(user);
			tx.commit();
		} catch (Exception e) {
			isInsert = 0;
			tx.rollback();
			throw new ETSException("Exception when add/update the task: "+e.getMessage());
		}
		 finally {
	        	session.close();
	        }
				return isInsert;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<UserLogin> getUsers() throws ETSException{
		List<UserLogin> users = null;
		@SuppressWarnings("rawtypes")
		Map loginSession = (Map) ActionContext.getContext().get("session");
		BUId = (Integer) loginSession.get("BUId");
		System.out.println("BUId is****"+BUId);
		Session session = HibernateUtil.getInstance().openSession();
		try {
			if(BUId==1){
			users = session.createQuery("from UserLogin t order by t.userName").list();
			}
			else{
			users = session.createQuery("from UserLogin t where t.BU.BUId='"+BUId+"' order by t.userName").list();
			}
			System.out.println("USERS******"+users);
		} catch (Exception e) {
			throw new ETSException("Exception when getting the user list: "+e.getMessage());
		}
		 finally {
	        	session.close();
	        }
		return users;
	}

	@Override
	public UserLogin getUser(Integer userId) throws ETSException{
		UserLogin user = null;
		Session session = HibernateUtil.getInstance().openSession();
		try {
			UserLogin temp = (UserLogin) session.get(UserLogin.class, userId);
			user = temp;
			System.out.println("USER"+user);
		} catch (Exception e) {
			throw new ETSException("Exception when getting the user: "+e.getMessage());
		}
		 finally {
	        	session.close();
	        }
		return user;
	}

	@Override
	public int deleteUser(Integer userId) throws ETSException{
		Integer isDelete = 1;
		Session session = HibernateUtil.getInstance().openSession();
		Transaction tx= session.beginTransaction();
		try {
			tx.begin();
			UserLogin user = (UserLogin) session.get(UserLogin.class, userId);
			session.delete(user);
			tx.commit();
		} catch (Exception e) {
			isDelete = 0;
			tx.rollback();
			throw new ETSException("Exception when deleting the user: "+e.getMessage());
		}
		 finally {
	        	session.close();
	        }
		return isDelete;
	}
}
