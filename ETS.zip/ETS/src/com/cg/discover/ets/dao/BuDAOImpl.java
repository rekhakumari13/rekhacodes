package com.cg.discover.ets.dao;

import java.util.List;
import java.util.Map;

import com.cg.discover.ets.utility.HibernateUtil;

import org.hibernate.Session;

import com.cg.discover.ets.entity.BU;
import com.cg.discover.ets.exception.ETSException;
import com.opensymphony.xwork2.ActionContext;

public class BuDAOImpl implements BuDAO {

	private Integer BUId;
	@SuppressWarnings("unchecked")
	@Override
	public List<BU> getBUList() throws ETSException {
		List<BU> buList = null;
		@SuppressWarnings("rawtypes")
		Map loginSession = (Map) ActionContext.getContext().get("session");
		BUId = (Integer) loginSession.get("BUId");
		System.out.println("BUId is****"+BUId);
		Session session = HibernateUtil.getInstance().openSession();
		try {
			if(BUId==1){
				buList = session.createQuery("from BU b order by b.BUId").list();
			}
			else{
				buList = session.createQuery("from BU b where b.BU.BUId='"+BUId+"' order by b.BUId").list();
			}
			System.out.println("HELLO NITESH"+buList);
		} catch (Exception e) {
			throw new ETSException("Exception when getting the BU list: "+e.getMessage());
		}
		 finally {
	        	session.close();
	        }
		return buList;
	}
	@Override
	public BU getBU(Integer buId) throws ETSException {
		BU bu  = null;
		Session session = HibernateUtil.getInstance().openSession();
		try {
			bu = (BU) session.createQuery("from BU b where b.BUId = "+buId).list().get(0);
			
		} catch (Exception e) {
			throw new ETSException("Exception when getting the BU : "+e.getMessage());
		}
		 finally {
	        	session.close();
	        }
		return bu;
	}
}
