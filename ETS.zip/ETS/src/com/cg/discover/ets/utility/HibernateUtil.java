package com.cg.discover.ets.utility;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;


public class HibernateUtil {

	
	private static org.hibernate.SessionFactory sessionFactory;


	private HibernateUtil() {
	}

	static {
		try {
			sessionFactory = new Configuration().configure()
					.buildSessionFactory();
		} catch (Throwable ex) {
			ex.printStackTrace(System.out);
			throw new ExceptionInInitializerError(ex);
		}
	}


	public static SessionFactory getInstance() {
		return sessionFactory;
	}


	public Session openSession() {
		return sessionFactory.openSession();
	}

	public Session getCurrentSession() {
		return sessionFactory.getCurrentSession();
	}


}
