/**
 * 
 */
package com.cg.discover.ets.utility;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import com.cg.discover.ets.vo.DateVO;

/**
 * @author nranjan
 *
 */
public class Utils {
	
	List<String> dateList = new ArrayList<String>(); 

	
	public static Map<String,String> getMonthList(){
		Map<String,String> months = new LinkedHashMap<String,String>();
		months.put("1","January");
		months.put("2","February");
		months.put("3","March");
		months.put("4","April");
		months.put("5","May");
		months.put("6","June");
		months.put("7","July");
		months.put("8","August");
		months.put("9","September");
		months.put("10","October");
		months.put("11","November");
		months.put("12","December");
		return months;
	}
	
	public static Map<String,String> getYearList(){
		Map<String,String> years = new TreeMap<String,String>();
		years.put("2015","2015");
		years.put("2016","2016");
		years.put("2017","2017");
		years.put("2018","2018");
		years.put("2019","2019");
		years.put("2020","2020");
		return years;
	}
	
	public static List<DateVO> getDateList(String month, String year){
		List<DateVO> dateList = new ArrayList<DateVO>();
		int dateRange = getDateRange(month, year);
		if(!(month.equals("10")|| month.equals("11") || month.equals("12"))){
			month = "0"+month;
		}
		
		for(int i=1; i<= dateRange; i++){
			DateVO  dateVO = null;
			if(i<10){
				dateVO = new DateVO("0"+i,"0"+i+"/"+month+"/"+year);
			}else{
				dateVO = new DateVO(""+i, i+"/"+month+"/"+year);
			}
			dateList.add(dateVO);
		}
		return dateList;
	}

	
	public static int getDateRange(String month, String year){
		int dateRange = 28;
		if(null != month && year != null){
			int y = Integer.parseInt(year);
			if(month.equals("1") || month.equals("3") || month.equals("5") || month.equals("7") || month.equals("8") || month.equals("10") || month.equals("12")){
				dateRange = 31;
			}else if(month.equals("4") || month.equals("6") || month.equals("9") || month.equals("11")){
				dateRange = 30;
			}	
			else if(y%400 ==0  || (y%4 == 0 && y % 100 != 0) ){
				dateRange = 29;
			}
		}
		return dateRange;
	}

}
