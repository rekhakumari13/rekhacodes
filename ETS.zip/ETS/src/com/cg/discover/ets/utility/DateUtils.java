/**
 * 
 */
package com.cg.discover.ets.utility;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @author nranjan
 *
 */
public class DateUtils {
	
	public static Date getDate(String strDate){
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		Date date = null;
		try {
			date = sdf.parse(strDate);
		} catch (ParseException e) {
			System.out.println("Exception in Parsing Date");
		}
		return date;
	}	
	
	
	public static String getFormattedDateMonthYear(Date inputDate){
		SimpleDateFormat outputDateFormat = new SimpleDateFormat("dd/MM/yyyy");
		return outputDateFormat.format(inputDate);
	}
	
}
