package com.cg.discover.ets.service;

import java.util.List;

import com.cg.discover.ets.dao.TaskDAO;
import com.cg.discover.ets.dao.TaskDAOImpl;
import com.cg.discover.ets.entity.Task;
import com.cg.discover.ets.exception.ETSException;
import com.cg.discover.ets.vo.TaskList;
import com.cg.discover.ets.vo.TaskListUpdate;


;

public class TaskServiceImpl implements TaskService {

	TaskDAO taskDAO = new TaskDAOImpl();

	@Override
	public int addAndUpdateTask(Integer taskId, String taskName,
			String taskDescription,Integer BUId) throws ETSException {

		Task task = new Task();
		task.setTaskId(taskId);
		task.setTaskName(taskName);
		task.setTaskDescription(taskDescription);
		task.setBUId(BUId);
		int status = taskDAO.addAndUpdateTask(task);

		return status;

	}

	@Override
	public int deleteTask(int taskID) throws ETSException{

		return taskDAO.deleteTask(taskID);
	}

	@Override
	public List<TaskList> getTasks() throws ETSException {
		return taskDAO.getTasks();
	}
	
	@Override
	public List<TaskListUpdate> getTask(Integer taskId) throws ETSException {
		return taskDAO.getTask(taskId);
	}

	
	/*public Task getTask(Integer taskId) throws ETSException {
		return taskDAO.getTask(taskId);
	}*/

	@Override
	public List<Task> getTasksForEffort() throws ETSException {
		return taskDAO.getTasksForEffort();
	}
	public List<Task> getTasksForSelectedUser(String userName) throws ETSException{
		return taskDAO.getTasksForSelectedUser(userName);
	}
}
