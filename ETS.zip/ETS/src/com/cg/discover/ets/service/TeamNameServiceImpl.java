package com.cg.discover.ets.service;

import java.util.List;
import java.util.Set;

import com.cg.discover.ets.dao.TeamNameDAO;
import com.cg.discover.ets.dao.TeamNameDAOImpl;
import com.cg.discover.ets.entity.Team;
import com.cg.discover.ets.entity.UserLogin;
import com.cg.discover.ets.exception.ETSException;

;

public class TeamNameServiceImpl implements TeamNameService {

	TeamNameDAO teamnameDAO = new TeamNameDAOImpl();

	@Override
	public Set<Team> getTeamNameList() throws ETSException {
		return teamnameDAO.getTeamNameList();
	}
	public Set<Team> getTeamNamesById(Integer bUId) throws ETSException {
		return teamnameDAO.getTeamNamesById(bUId);
	}
	
	@Override
	public List<UserLogin> getEmployeesName(String teamId, Integer BUId) throws ETSException {
		return teamnameDAO.getEmployeesName(teamId, BUId);
	}
}
