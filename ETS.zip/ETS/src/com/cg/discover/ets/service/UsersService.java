package com.cg.discover.ets.service;

import java.util.List;

import com.cg.discover.ets.entity.User;
import com.cg.discover.ets.exception.ETSException;

public interface UsersService {
	public List<User> getUsers() throws ETSException;
	
}
