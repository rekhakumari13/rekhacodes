package com.cg.discover.ets.service;

import java.util.List;

import com.cg.discover.ets.entity.Task;
import com.cg.discover.ets.exception.ETSException;
import com.cg.discover.ets.vo.TaskList;
import com.cg.discover.ets.vo.TaskListUpdate;

public interface TaskService {
	public int addAndUpdateTask(Integer taskId,String taskName,String taskDescription,Integer BUId) throws ETSException;
	public int deleteTask(int taskID) throws ETSException;
	public List<TaskList> getTasks() throws ETSException;
	public List<TaskListUpdate> getTask(Integer taskId) throws ETSException;
	//public Task getTask(Integer taskId) throws ETSException;
	public List<Task> getTasksForEffort() throws ETSException;
	public List<Task> getTasksForSelectedUser(String userName) throws ETSException;
}
