package com.cg.discover.ets.service;

import java.util.Map;

import com.cg.discover.ets.dao.LoginDAO;
import com.cg.discover.ets.dao.LoginDAOImpl;
import com.cg.discover.ets.entity.UserLogin;
import com.cg.discover.ets.exception.ETSException;
import com.opensymphony.xwork2.ActionContext;

public class LoginServiceImpl implements LoginService{
	Boolean status = null;
	UserLogin userLogin;
	LoginDAO loginDao = new LoginDAOImpl();
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public Boolean login(String userName,String password) throws ETSException{
		userLogin=loginDao.loginDAO(userName);
		
		System.out.println(userLogin);
		//System.out.println(userLogin.getBU());
		Map session = ActionContext.getContext().getSession();
		
		if(userLogin!=null && userLogin.getPassword().equals(password)){
			if(userLogin.getIsAdmin()){
				session.put("isAdmin", true);
			}else{
				session.put("isAdmin", false);
			}
			session.put("userName", userName);
			session.put("BUId", userLogin.getBU().getBUId());
			session.put("employeeName", userLogin.getEmployeeName());
			session.put("teamName", userLogin.getTeam().getTeamName());
			session.put("buName", userLogin.getBU().getBU());
			session.put("userId", userLogin.getUserId());
			status = true;
		}else{
			status= false;
		}
		return status;
		
	}

	@Override
	public String changePassword(String oldPassword, String newPassword)
			throws ETSException {
		@SuppressWarnings("rawtypes")
		Map session = (Map) ActionContext.getContext().get("session");
		System.out.println(session.get("userName"));
		String pwd= loginDao.loginDAO((String)session.get("userName")).getPassword();
		if(oldPassword.equals(pwd))
			{
			userLogin=loginDao.loginDAO((String) session.get("userName"));
			userLogin.setPassword(newPassword);
		    if(loginDao.changePassword(userLogin)==true)
		    	return "success";
		    else 
		    	return "failure";
			}
		else
			return "failure";
	}
	}


