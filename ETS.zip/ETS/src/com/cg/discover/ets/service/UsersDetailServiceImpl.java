package com.cg.discover.ets.service;

import java.util.List;

import com.cg.discover.ets.dao.BuDAO;
import com.cg.discover.ets.dao.BuDAOImpl;
import com.cg.discover.ets.dao.TeamNameDAO;
import com.cg.discover.ets.dao.TeamNameDAOImpl;
import com.cg.discover.ets.dao.UsersDetailDAO;
import com.cg.discover.ets.dao.UsersDetailDAOImpl;
import com.cg.discover.ets.entity.BU;
import com.cg.discover.ets.entity.Team;
import com.cg.discover.ets.entity.UserLogin;
import com.cg.discover.ets.exception.ETSException;


;

public class UsersDetailServiceImpl implements UsersDetailService {

	UsersDetailDAO usersDetailDAO = new UsersDetailDAOImpl();
	BuDAO buDAO = new BuDAOImpl();
	TeamNameDAO teamnameDAO = new TeamNameDAOImpl();

	@Override
	public int addAndUpdateUser(Integer userId,String userName,String password,String employeeName,String employeeID,Integer buId,Integer teamNameId,String emailID,Boolean isAdmin) throws ETSException{

		UserLogin user = new UserLogin();
		user.setUserId(userId);
		user.setUserName(userName);
		user.setPassword(password);
		user.setEmployeeName(employeeName);
		user.setEmployeeID(employeeID);
		BU bu = buDAO.getBU(buId);
		user.setBU(bu);
		Team team = teamnameDAO.getTeamName(teamNameId);
		user.setTeam(team);
		user.setEmailID(emailID);
		user.setIsAdmin(isAdmin);
		

		int status = usersDetailDAO.addAndUpdateUser(user);

		return status;

	}

	@Override
	public int deleteUser(Integer userId) throws ETSException{

		return usersDetailDAO.deleteUser(userId);
	}

	@Override
	public List<UserLogin> getUsers() throws ETSException{
		return usersDetailDAO.getUsers();
	}

	public UserLogin getUser(Integer userId) throws ETSException{
		return usersDetailDAO.getUser(userId);
	}

}
