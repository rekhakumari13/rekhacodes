package com.cg.discover.ets.service;

import java.util.List;

import com.cg.discover.ets.dao.UserDAO;
import com.cg.discover.ets.dao.UserDAOImpl;
import com.cg.discover.ets.entity.User;
import com.cg.discover.ets.exception.ETSException;


;

public class UsersServiceImpl implements UsersService {

	UserDAO userDAO = new UserDAOImpl();

	
	@Override
	public List<User> getUsers() throws ETSException {
		return userDAO.getUsers();
	}

}
