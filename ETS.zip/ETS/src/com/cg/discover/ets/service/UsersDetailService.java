package com.cg.discover.ets.service;

import java.util.List;

import com.cg.discover.ets.entity.BU;
import com.cg.discover.ets.entity.UserLogin;
import com.cg.discover.ets.exception.ETSException;

public interface UsersDetailService {
	public int addAndUpdateUser(Integer userId,String userName,String password,String employeeName,String employeeID,Integer buId,Integer teamNameId,String emailID,Boolean isAdmin) throws ETSException;
	public int deleteUser(Integer userId) throws ETSException;
	public List<UserLogin> getUsers() throws ETSException;
	public UserLogin getUser(Integer userId) throws ETSException;
}
