package com.cg.discover.ets.service;

import java.util.List;

import com.cg.discover.ets.entity.BU;
import com.cg.discover.ets.exception.ETSException;

public interface BuService {
	
	public List<BU> getBUList() throws ETSException;
	
}
