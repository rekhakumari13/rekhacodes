package com.cg.discover.ets.service;

import java.util.List;

import com.cg.discover.ets.exception.ETSException;
import com.cg.discover.ets.vo.UserSearch;
import com.cg.discover.ets.vo.UsersReport;

public interface UsersReportService {
	
	public List<UsersReport> gerUsersReport(UserSearch userSearch) throws ETSException;
	
}
