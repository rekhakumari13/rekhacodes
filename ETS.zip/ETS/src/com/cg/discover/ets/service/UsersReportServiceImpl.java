package com.cg.discover.ets.service;

import java.util.List;

import com.cg.discover.ets.dao.UsersReportDao;
import com.cg.discover.ets.dao.UsersReportDaoImpl;
import com.cg.discover.ets.exception.ETSException;
import com.cg.discover.ets.vo.UserSearch;
import com.cg.discover.ets.vo.UsersReport;


;

public class UsersReportServiceImpl implements UsersReportService {

	UsersReportDao dao = new UsersReportDaoImpl();
	
	public List<UsersReport> gerUsersReport(UserSearch userSearch) throws ETSException {
		return dao.gerUsersReport(userSearch);
	}

}
