package com.cg.discover.ets.service;

import java.util.List;

import com.cg.discover.ets.dao.BuDAO;
import com.cg.discover.ets.dao.BuDAOImpl;
import com.cg.discover.ets.entity.BU;
import com.cg.discover.ets.exception.ETSException;


;

public class BuServiceImpl implements BuService {

	BuDAO buDAO = new BuDAOImpl();

	@Override
	public List<BU> getBUList() throws ETSException {
		return buDAO.getBUList();
	}


}
