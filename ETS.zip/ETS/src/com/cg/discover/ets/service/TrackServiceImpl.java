package com.cg.discover.ets.service;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.cg.discover.ets.dao.TaskDAO;
import com.cg.discover.ets.dao.TaskDAOImpl;
import com.cg.discover.ets.dao.TrackDAO;
import com.cg.discover.ets.dao.TrackDAOImpl;
import com.cg.discover.ets.entity.Task;
import com.cg.discover.ets.entity.TaskTime;
import com.cg.discover.ets.entity.Track;
import com.cg.discover.ets.exception.ETSException;
import com.cg.discover.ets.utility.DateUtils;

;

public class TrackServiceImpl implements TrackService {

	TrackDAO trackDAO = new TrackDAOImpl();
	TaskDAO taskDAO = new TaskDAOImpl();

	@Override
	public boolean addAndUpdateTrack(List<Track> tracks) throws ETSException {
		return trackDAO.addAndUpdateTrack(tracks);
	}


	/* (non-Javadoc)
	 * @see com.cg.discover.ets.service.TrackService#getTrackListBySearchCriteria(java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public List<Track> getTrackListBySearchCriteria(String userName,String month, String year) throws ETSException {
		
		List<Track> tracks = trackDAO.getTrackListBySearchCriteria(userName,month,year);
		Set<Task> updatedTaskSet = new HashSet<Task>();
		Set<Task> finalTaskSet = null;
		//List<Task> taskList = taskDAO.getTasks();
		List<Task> taskList = taskDAO.getTasksForEffort();

		if (null != tracks && tracks.size() != 0) {
			for (Track track : tracks) {
				if (null != track.getTaskDate()) {
					track.setTaskDateStr(DateUtils.getFormattedDateMonthYear(track.getTaskDate()));
				}
				if (null != track.getTaskTimeSet()
						&& 0 != track.getTaskTimeSet().size()) {
					Set<TaskTime> taskTimeSet = track.getTaskTimeSet();

					for (TaskTime taskTime : taskTimeSet) {
						if (null != taskTime.getTask()) {
							updatedTaskSet.add(taskTime.getTask());
						}
					}
				}
			}
		}

		if (null != tracks && tracks.size() != 0) {
			finalTaskSet = new HashSet<Task>();
			finalTaskSet.addAll(taskList);
			for (Task task : updatedTaskSet) {
				if (taskList.contains(task)) {
					finalTaskSet.remove(task);
				}

			}
			for (Track track : tracks) {
				if (null != track.getTaskTimeSet()
						&& 0 != track.getTaskTimeSet().size()) {
					Set<TaskTime> taskTimeSet = track.getTaskTimeSet();

					for (Task task : finalTaskSet) {
						TaskTime tt = new TaskTime();
						tt.setTask(task);
						taskTimeSet.add(tt);
					}
				}
			}
		}

		return tracks;
	}
}
