package com.cg.discover.ets.service;

import com.cg.discover.ets.exception.ETSException;

public interface LoginService {
	public Boolean login(String userName,String password) throws ETSException;
	public String changePassword(String oldPassword,String newPassword) throws ETSException;
}
