function getMonth(){
		document.getElementById("01").value = "01/"+document.getElementById("months").value+"/2015";
		document.getElementById("02").value = "02/"+document.getElementById("months").value+"/2015";
		document.getElementById("03").value = "03/"+document.getElementById("months").value+"/2015";
		document.getElementById("04").value = "04/"+document.getElementById("months").value+"/2015";
		document.getElementById("05").value = "05/"+document.getElementById("months").value+"/2015";
		document.getElementById("06").value = "05/"+document.getElementById("months").value+"/2015";
		document.getElementById("07").value = "06/"+document.getElementById("months").value+"/2015";
		document.getElementById("08").value = "07/"+document.getElementById("months").value+"/2015";
		document.getElementById("09").value = "08/"+document.getElementById("months").value+"/2015";
		document.getElementById("10").value = "09/"+document.getElementById("months").value+"/2015";
		document.getElementById("11").value = "10/"+document.getElementById("months").value+"/2015";
		document.getElementById("12").value = "11/"+document.getElementById("months").value+"/2015";
		document.getElementById("13").value = "12/"+document.getElementById("months").value+"/2015";
}